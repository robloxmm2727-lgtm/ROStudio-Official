// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — ios/IOSPlatform.h
//  iOS platforma köməkçisi — QML tərəfindən çağırılır
// ═══════════════════════════════════════════════════════════════════════════════
#pragma once
#include <QObject>

class IOSPlatform : public QObject {
    Q_OBJECT
    Q_PROPERTY(qreal safeAreaTop    READ safeAreaTop    CONSTANT)
    Q_PROPERTY(qreal safeAreaBottom READ safeAreaBottom CONSTANT)

public:
    explicit IOSPlatform(QObject* parent = nullptr);

    qreal safeAreaTop()    const { return safeTop_; }
    qreal safeAreaBottom() const { return safeBottom_; }

    Q_INVOKABLE void hapticLight();
    Q_INVOKABLE void hapticSuccess();
    Q_INVOKABLE void hapticError();

private:
    qreal safeTop_    = 44.0; // iPhone 14 default
    qreal safeBottom_ = 34.0;
};
