// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — ios/IOSHelper.mm
//  iOS-a xüsusi Objective-C++ köməkçiləri
//  - Cihaz barmaq izi (identifierForVendor)
//  - Safe Area insets (notch / Dynamic Island)
//  - Haptic feedback
//  - Face ID / Touch ID (BiometricAuth)
// ═══════════════════════════════════════════════════════════════════════════════
#import <UIKit/UIKit.h>
#import <LocalAuthentication/LocalAuthentication.h>
#include <QString>
#include <functional>

// ─── iOS Cihaz Barmaq İzi ────────────────────────────────────────────────────
// DeviceKey.cpp-nin iOS override-ı
// JS-dəki getDeviceKey() → iOS-da identifierForVendor istifadə edir
extern "C" {
    const char* ios_getDeviceIdentifier() {
        NSString* vendorId = [[[UIDevice currentDevice]
            identifierForVendor] UUIDString];
        if (!vendorId) vendorId = @"unknown-ios-device";
        return [vendorId UTF8String];
    }

    // Safe area (iPhone X+ notch / Dynamic Island hündürlüyü)
    float ios_getSafeAreaTop() {
        if (@available(iOS 11.0, *)) {
            UIWindow* window = [UIApplication sharedApplication].windows.firstObject;
            return window.safeAreaInsets.top;
        }
        return 20.0f;
    }

    float ios_getSafeAreaBottom() {
        if (@available(iOS 11.0, *)) {
            UIWindow* window = [UIApplication sharedApplication].windows.firstObject;
            return window.safeAreaInsets.bottom;
        }
        return 0.0f;
    }

    // Haptic feedback (düymə basıldıqda)
    void ios_hapticLight() {
        UIImpactFeedbackGenerator* gen = [[UIImpactFeedbackGenerator alloc]
            initWithStyle:UIImpactFeedbackStyleLight];
        [gen impactOccurred];
    }

    void ios_hapticSuccess() {
        UINotificationFeedbackGenerator* gen =
            [[UINotificationFeedbackGenerator alloc] init];
        [gen notificationOccurred:UINotificationFeedbackTypeSuccess];
    }

    void ios_hapticError() {
        UINotificationFeedbackGenerator* gen =
            [[UINotificationFeedbackGenerator alloc] init];
        [gen notificationOccurred:UINotificationFeedbackTypeError];
    }
}

// ─── Face ID / Touch ID ───────────────────────────────────────────────────────
// Gələcəkdə auto-login üçün
void ios_authenticateWithBiometrics(
    const char* reason,
    std::function<void(bool success, const char* error)> callback)
{
    LAContext* ctx = [[LAContext alloc] init];
    NSError* err = nil;
    NSString* reasonStr = [NSString stringWithUTF8String:reason];

    if ([ctx canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics
                         error:&err]) {
        [ctx evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics
            localizedReason:reasonStr
                      reply:^(BOOL success, NSError* _Nullable error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (success) {
                    callback(true, nullptr);
                } else {
                    const char* msg = error ?
                        [error.localizedDescription UTF8String] : "Biometrik uğursuz";
                    callback(false, msg);
                }
            });
        }];
    } else {
        callback(false, "Biometrik dəstəklənmir");
    }
}
