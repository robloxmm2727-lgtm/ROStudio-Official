# 🚀 ROStudio — GitHub Actions ilə APK/IPA Build

## 📋 Addım-addım təlimat (Telefonda)

---

### 1️⃣ GitHub hesabı aç
- [github.com](https://github.com) → Sign up (pulsuz)

---

### 2️⃣ Yeni repo yarat
```
GitHub → "+" → "New repository"
Name: ROStudio
Private: ✅ (şəxsi saxla)
"Create repository" bas
```

---

### 3️⃣ Faylları yüklə
```
Repo → "Add file" → "Upload files"
→ ROStudio_CPP.zip faylını seç
→ "Commit changes" bas
```

**YA DA** GitHub Desktop tətbiqi ilə:
```
GitHub Desktop → Clone repo → Faylları kopyala → Push
```

---

### 4️⃣ Actions avtomatik işə düşür!
```
Repo → "Actions" tab
→ "ROStudio Build (Android + iOS)" workflow görəcəksən
→ Yaşıl ✅ olana qədər gözlə (~20 dəqiqə)
```

---

### 5️⃣ APK-nı endir
```
Actions → Son build → "Artifacts" bölməsi
→ "ROStudio-Android-APK" → Endir
→ .zip aç → .apk faylı var
→ Telefona qur!
```

---

## ⚠️ Bilməli olduqların

| Məsələ | Həll |
|---|---|
| Build uğursuz oldu | Actions → Log-a bax → Mənə göndər |
| APK qurulmur | "Naməlum mənbə" icazəsini aç |
| iOS IPA | AltStore və ya Sideloadly lazımdır |

---

## 📁 Fayl strukturu (GitHub-da belə görünməlidir)

```
ROStudio/
├── .github/
│   └── workflows/
│       └── build.yml        ← Actions workflow
├── android/
│   ├── AndroidManifest.xml
│   ├── build.gradle.kts
│   └── res/
│       ├── xml/network_security_config.xml
│       └── values/styles.xml
├── ios/
│   ├── Info.plist
│   ├── IOSHelper.mm
│   └── IOSPlatform.h
├── src/                     ← C++ mənbə kodları
├── qml/                     ← QML UI faylları
├── resources/
│   └── resources.qrc
├── CMakeLists.txt
└── README.md
```

---

## 🔑 Anthropic API açarı əlavə etmək

Build etməzdən əvvəl `src/api/AnthropicApi.cpp` faylında:

```cpp
// Bu sətri tap:
// req.setRawHeader("x-api-key", anthropicApiKey.toUtf8());

// Və belə et:
req.setRawHeader("x-api-key", "sk-ant-SƏNIN_AÇARIN_BURAYA");
```

**YA DA** GitHub Secrets istifadə et (daha təhlükəsiz):
```
Repo → Settings → Secrets → "ANTHROPIC_API_KEY" əlavə et
```

---

> **by CyberWeld** — ROStudio v5.0.0
