# ROStudio v5 — Native C++ / Qt6 Edition
### by CyberWeld | HTML/JS PWA → Native C++ çevirişi

---

## 📁 Layihə Strukturu

```
ROStudio_CPP/
├── CMakeLists.txt              ← Əsas build faylı
├── src/
│   ├── main.cpp                ← Tətbiq giriş nöqtəsi
│   ├── core/
│   │   └── AppController.cpp/h  ← MVC Kontrolör (bütün JS loqikası)
│   ├── api/
│   │   ├── RobloxApi.cpp/h      ← Roblox Open Cloud REST müştərisi
│   │   ├── AnthropicApi.cpp/h   ← Claude AI inteqrasiyası
│   │   └── ApiResponse.h        ← Veri strukturları
│   ├── crypto/
│   │   ├── AesGcm.cpp/h         ← AES-256-GCM (OpenSSL, WebCrypto uyğun)
│   │   ├── DeviceKey.cpp/h      ← Cihaz barmaq izi (JS getDeviceKey() qarşılığı)
│   │   └── SecureStorage.cpp/h  ← localStorage → şifrəli JSON fayl
│   ├── ui/
│   │   ├── DashboardModel.cpp/h ← Dashboard panel modeli
│   │   ├── TerminalModel.cpp/h  ← Terminal log modeli (QAbstractListModel)
│   │   ├── DataStoreModel.cpp/h ← DataStore siyahı modeli
│   │   ├── AiChatModel.cpp/h    ← AI söhbət modeli
│   │   └── AnnounceModel.cpp/h  ← Elan tarixçəsi modeli
│   └── i18n/
│       └── Translator.cpp/h     ← 4 dil (EN/AZ/TR/RU)
├── qml/
│   ├── main.qml                 ← Kök pəncərə, ekran marşrutu
│   ├── components/
│   │   ├── LoginScreen.qml      ← Giriş ekranı (animasiyalarla)
│   │   ├── MainScreen.qml       ← Əsas tətbiq (StackLayout)
│   │   ├── TopBar.qml           ← Üst panel
│   │   ├── NavTabs.qml          ← Tab naviqasiyası
│   │   ├── Toast.qml            ← Bildiriş popup-u
│   │   ├── ApiModal.qml         ← API açarı modalı
│   │   ├── StatCard.qml         ← Statistika kartı
│   │   ├── GameCard.qml         ← Oyun kartı
│   │   └── BarChart.qml         ← Canvas bar qrafiki
│   └── panels/
│       ├── DashboardPanel.qml   ← Dashboard paneli
│       ├── TerminalPanel.qml    ← Terminal paneli
│       ├── DataStorePanel.qml   ← DataStore paneli
│       ├── AiPanel.qml          ← AI söhbət paneli
│       ├── AnnouncePanel.qml    ← Elan paneli
│       ├── TeamPanel.qml        ← Komanda paneli
│       └── SettingsPanel.qml    ← Parametrlər paneli
└── resources/
    └── resources.qrc            ← Qt resurs faylı
```

---

## 🔧 Qurulum Tələbləri

| Asılılıq | Versiya | Qeyd |
|---|---|---|
| Qt | 6.5+ | Quick, Network, Qml, QuickControls2 |
| CMake | 3.20+ | |
| OpenSSL | 3.x | AES-256-GCM üçün |
| C++ Standartı | C++20 | |

### Linux/macOS
```bash
# Qt6 qur
# Ubuntu: sudo apt install qt6-base-dev qt6-declarative-dev libssl-dev
# macOS:  brew install qt6 openssl

# Layihəni build et
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)
./ROStudio
```

### Windows
```bash
# Qt Creator ilə aç: CMakeLists.txt
# Build → Run
```

### Android (Qt for Android)
```bash
cmake .. -DANDROID_ABI=arm64-v8a \
         -DANDROID_NDK=$ANDROID_NDK \
         -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake
```

---

## 🔄 JS → C++ Çevrilmə Xəritəsi

| JavaScript/HTML | C++ / QML |
|---|---|
| `localStorage.setItem()` | `SecureStorage::store()` → `~/.config/ROStudio/secure.dat` |
| `localStorage.getItem()` | `SecureStorage::load()` |
| `WebCrypto AES-256-GCM` | `AesGcm::encrypt/decrypt()` (OpenSSL) |
| `getDeviceKey()` | `DeviceKey::get()` (Qt system info) |
| `fetch()` + `async/await` | `QNetworkAccessManager` + signals/slots |
| `setInterval(fn, 30000)` | `QTimer` (30000ms) |
| `LANGS{}` + `t(key)` | `Translator` class |
| `appendTermLine()` | `TerminalModel::appendLine()` |
| `buildChart()` | `BarChart.qml` Canvas |
| `callClaudeAI()` | `AnthropicApi::sendMessage()` |
| `document.getElementById()` | QML property bindings |
| `HTML panels` | QML StackLayout panelləri |
| `CSS variables` | QML `theme` QtObject |
| `CSS animations` | QML `SequentialAnimation`, `NumberAnimation` |

---

## 🔐 Təhlükəsizlik

- **AES-256-GCM** şifrələmə (OpenSSL PBKDF2-SHA256, 310.000 iterasiya)
- **Salt (16B) + IV (12B)** hər şifrələmədə yenilənir
- **GCM auth tag (16B)** — məlumat bütövlüyü yoxlanılır
- **Cihaz barmaq izi** şifrələmə açarı kimi istifadə edilir
- **Sıfır şəbəkə sızması** — API açarı yalnız cihazda saxlanılır
- Fayl: `~/.config/ROStudio/secure.dat`

---

## 📝 Qeydlər

1. **Anthropic API açarı** — `AnthropicApi.cpp`-də `x-api-key` başlığına əlavə edilməlidir
2. **CORS** — C++-da lazım deyil, birbaşa Roblox API-yə qoşulur
3. **PWA** → Native fayl sistemi istifadə edilir
4. **Service Worker** → Qt-nin cache mexanizmi
