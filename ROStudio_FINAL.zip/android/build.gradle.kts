// ROStudio — Android Gradle Build
plugins {
    id("com.android.application")
}

android {
    namespace = "dev.cyberweld.rostudio"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.cyberweld.rostudio"
        minSdk = 29
        targetSdk = 34
        versionCode = 500
        versionName = "5.0.0"

        // ABI filtri — yalnız 64-bit ARM (müasir telefonlar)
        ndk {
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                arguments(
                    "-DANDROID_STL=c++_shared",
                    "-DOPENSSL_ROOT_DIR=\${rootDir}/openssl-android",
                    "-DBUILD_TARGET=Android"
                )
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = false // Qt kitabxanaları üçün false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug") // Test üçün
        }
        debug {
            isDebuggable = true
            applicationIdSuffix = ".debug"
        }
    }

    externalNativeBuild {
        cmake {
            path = file("../CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Qt kitabxana faylları
    sourceSets {
        getByName("main") {
            manifest.srcFile("AndroidManifest.xml")
            res.srcDirs("res")
            jniLibs.srcDirs("libs")
        }
    }

    packaging {
        jniLibs {
            useLegacyPackaging = false
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
}
