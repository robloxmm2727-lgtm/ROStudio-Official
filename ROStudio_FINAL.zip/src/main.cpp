// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio v5 — main.cpp
//  Tətbiq giriş nöqtəsi — C++ tipləri QML-ə qeydiyyatdan keçirilir
// ═══════════════════════════════════════════════════════════════════════════════
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QIcon>
#include <QFontDatabase>

#include "core/AppController.h"
#include "ui/DashboardModel.h"
#include "ui/TerminalModel.h"
#include "ui/DataStoreModel.h"
#include "ui/AiChatModel.h"
#include "ui/AnnounceModel.h"
#include "i18n/Translator.h"

int main(int argc, char* argv[])
{
    // ─── Qt tətbiq konfiqurasiyası ────────────────────────────────────────────
    QGuiApplication::setApplicationName("ROStudio");
    QGuiApplication::setApplicationVersion("5.0.0");
    QGuiApplication::setOrganizationName("CyberWeld");
    QGuiApplication::setOrganizationDomain("cyberweld.dev");

    QGuiApplication app(argc, argv);
    app.setWindowIcon(QIcon(":/icons/rostudio.svg"));

    // ─── Qt Quick Controls 2 stil ─────────────────────────────────────────────
    QQuickStyle::setStyle("Basic"); // Native olmayan, ümumi stil

    // ─── C++ tip qeydiyyatları (QML bunları birbaşa istifadə edə bilər) ───────
    qmlRegisterUncreatableType<DashboardModel>("ROStudio", 1, 0,
        "DashboardModel", "C++ tərəfindən idarə edilir");
    qmlRegisterUncreatableType<TerminalModel>("ROStudio", 1, 0,
        "TerminalModel", "C++ tərəfindən idarə edilir");
    qmlRegisterUncreatableType<DataStoreModel>("ROStudio", 1, 0,
        "DataStoreModel", "C++ tərəfindən idarə edilir");
    qmlRegisterUncreatableType<AiChatModel>("ROStudio", 1, 0,
        "AiChatModel", "C++ tərəfindən idarə edilir");
    qmlRegisterUncreatableType<AnnounceModel>("ROStudio", 1, 0,
        "AnnounceModel", "C++ tərəfindən idarə edilir");
    qmlRegisterUncreatableType<Translator>("ROStudio", 1, 0,
        "Translator", "C++ tərəfindən idarə edilir");

    // ─── Əsas kontrolör (QML kontekstinə əlavə edilir) ───────────────────────
    AppController controller;

    // ─── QML mühərriki ────────────────────────────────────────────────────────
    QQmlApplicationEngine engine;

    // Kontrolörü QML-ə ötür (JS-dəki global dəyişənlər kimi)
    engine.rootContext()->setContextProperty("app", &controller);

    // Əsas QML faylını yüklə
    const QUrl url(u"qrc:/ROStudio/qml/main.qml"_qs);
    QObject::connect(
        &engine, &QQmlApplicationEngine::objectCreated,
        &app, [url](QObject* obj, const QUrl& objUrl) {
            if (!obj && url == objUrl) QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);

    engine.load(url);

    return app.exec();
}
