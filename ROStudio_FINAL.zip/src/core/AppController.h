#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — AppController.h
//  Əsas MVC Kontrolörü — bütün komponentləri birləşdirir
//  QML ↔ C++ körpüsü rolunu oynayır
//  JS-dəki: doLogin(), doLogout(), refreshAllData(), switchPanel() və s.
// ═══════════════════════════════════════════════════════════════════════════════
#include <QObject>
#include <QString>
#include <QTimer>
#include <QVector>
#include <memory>

#include "../api/RobloxApi.h"
#include "../api/AnthropicApi.h"
#include "../ui/DashboardModel.h"
#include "../ui/TerminalModel.h"
#include "../ui/DataStoreModel.h"
#include "../ui/AiChatModel.h"
#include "../ui/AnnounceModel.h"
#include "../i18n/Translator.h"

class AppController : public QObject {
    Q_OBJECT

    // ─── QML'ə açıq property-lər ─────────────────────────────────────────────
    Q_PROPERTY(bool       isLoggedIn   READ isLoggedIn   NOTIFY loginStateChanged)
    Q_PROPERTY(QString    activePanel  READ activePanel  NOTIFY activePanelChanged)
    Q_PROPERTY(QString    statusText   READ statusText   NOTIFY statusChanged)
    Q_PROPERTY(bool       isLive       READ isLive       NOTIFY statusChanged)
    Q_PROPERTY(QString    toastMsg     READ toastMsg     NOTIFY toastRequested)
    Q_PROPERTY(QString    toastType    READ toastType    NOTIFY toastRequested)
    Q_PROPERTY(QString    universeId   READ universeId   NOTIFY credentialsChanged)
    Q_PROPERTY(QString    maskedApiKey READ maskedApiKey NOTIFY credentialsChanged)
    Q_PROPERTY(QString    currentLang  READ currentLang  NOTIFY langChanged)

    // ─── Model property-ləri ──────────────────────────────────────────────────
    Q_PROPERTY(DashboardModel* dashboard READ dashboard CONSTANT)
    Q_PROPERTY(TerminalModel*  terminal  READ terminal  CONSTANT)
    Q_PROPERTY(DataStoreModel* dataStore READ dataStore CONSTANT)
    Q_PROPERTY(AiChatModel*    aiChat    READ aiChat    CONSTANT)
    Q_PROPERTY(AnnounceModel*  announce  READ announce  CONSTANT)
    Q_PROPERTY(Translator*     tr        READ translator CONSTANT)

public:
    explicit AppController(QObject* parent = nullptr);
    ~AppController() override;

    // ─── Property getter-ləri ─────────────────────────────────────────────────
    bool         isLoggedIn()   const { return isLoggedIn_; }
    QString      activePanel()  const { return activePanel_; }
    QString      statusText()   const { return statusText_; }
    bool         isLive()       const { return isLive_; }
    QString      toastMsg()     const { return toastMsg_; }
    QString      toastType()    const { return toastType_; }
    QString      universeId()   const { return universeId_; }
    QString      maskedApiKey() const;
    QString      currentLang()  const { return currentLang_; }

    DashboardModel* dashboard()  { return dashModel_.get(); }
    TerminalModel*  terminal()   { return termModel_.get(); }
    DataStoreModel* dataStore()  { return dsModel_.get(); }
    AiChatModel*    aiChat()     { return aiModel_.get(); }
    AnnounceModel*  announce()   { return announceModel_.get(); }
    Translator*     translator() { return translator_.get(); }

public slots:
    // ─── Auth işləri (JS: doLogin, doLogout) ─────────────────────────────────
    void doLogin(const QString& apiKey,
                 const QString& universeId,
                 const QString& placeId);
    void doLogout();
    void saveNewCredentials(const QString& apiKey,
                            const QString& universeId,
                            const QString& placeId);

    // ─── Panel keçidi (JS: switchPanel) ──────────────────────────────────────
    void switchPanel(const QString& panelName);

    // ─── Live yenilənmə (JS: refreshAllData, liveInterval) ───────────────────
    void refreshAllData();

    // ─── Terminal (JS: sendTermCmd, clearTerminal) ────────────────────────────
    void sendTerminalCommand(const QString& cmd);
    void clearTerminal();

    // ─── DataStore ────────────────────────────────────────────────────────────
    void loadDataStore(const QString& storeName = "PlayerData");

    // ─── AI Chat ─────────────────────────────────────────────────────────────
    void sendAiMessage(const QString& text);

    // ─── Elan (Announce) ─────────────────────────────────────────────────────
    void sendAnnouncement(const QString& text,
                          const QString& target,
                          const QString& schedType);

    // ─── Toast ────────────────────────────────────────────────────────────────
    void showToast(const QString& msg, const QString& type = "info");

    // ─── Dil ─────────────────────────────────────────────────────────────────
    void setLanguage(const QString& code);

    // ─── Yardımçı ─────────────────────────────────────────────────────────────
    Q_INVOKABLE QString formatBigNum(qint64 n) const;

signals:
    void loginStateChanged();
    void activePanelChanged();
    void statusChanged();
    void toastRequested();
    void credentialsChanged();
    void langChanged();
    void loginFailed(const QString& reason);
    void loginSuccess();

private:
    // ─── Daxili köməkçilər ────────────────────────────────────────────────────
    void loadSavedCredentials();
    void startLiveUpdates();
    void stopLiveUpdates();
    void applyGameInfo(const Api::UniverseInfo& info);
    void connectApiSignals();
    void initTerminal();

    // ─── Vəziyyət ─────────────────────────────────────────────────────────────
    bool    isLoggedIn_   = false;
    QString activePanel_  = "dashboard";
    QString statusText_   = "LIVE";
    bool    isLive_       = true;
    QString toastMsg_;
    QString toastType_;
    QString apiKey_;
    QString universeId_;
    QString placeId_;
    QString currentLang_  = "en";

    QVector<int> visitHistory_; // Qrafik üçün son 7 ölçüm (JS: visitHistory[])

    // ─── Komponentlər ─────────────────────────────────────────────────────────
    std::unique_ptr<Api::RobloxApi>    robloxApi_;
    std::unique_ptr<Api::AnthropicApi> anthropicApi_;
    std::unique_ptr<DashboardModel>    dashModel_;
    std::unique_ptr<TerminalModel>     termModel_;
    std::unique_ptr<DataStoreModel>    dsModel_;
    std::unique_ptr<AiChatModel>       aiModel_;
    std::unique_ptr<AnnounceModel>     announceModel_;
    std::unique_ptr<Translator>        translator_;

    QTimer* liveTimer_ = nullptr; // JS: liveInterval = setInterval(refreshAllData, 30000)
};
