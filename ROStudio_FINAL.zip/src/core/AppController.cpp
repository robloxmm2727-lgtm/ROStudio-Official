// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — AppController.cpp
//  Əsas MVC Kontrolörü implementasiyası
// ═══════════════════════════════════════════════════════════════════════════════
#include "AppController.h"
#include "../crypto/SecureStorage.h"
#include "../crypto/DeviceKey.h"
#include <QTimer>
#include <QDebug>
#include <QRegularExpression>

AppController::AppController(QObject* parent) : QObject(parent)
{
    // Komponentləri yarat
    robloxApi_    = std::make_unique<Api::RobloxApi>(this);
    anthropicApi_ = std::make_unique<Api::AnthropicApi>(this);
    dashModel_    = std::make_unique<DashboardModel>(this);
    termModel_    = std::make_unique<TerminalModel>(this);
    dsModel_      = std::make_unique<DataStoreModel>(this);
    aiModel_      = std::make_unique<AiChatModel>(this);
    announceModel_= std::make_unique<AnnounceModel>(this);
    translator_   = std::make_unique<Translator>(this);

    liveTimer_ = new QTimer(this);
    liveTimer_->setInterval(30000); // JS: 30 saniyəlik interval

    connectApiSignals();
    loadSavedCredentials(); // Auto-login cəhdi
}

AppController::~AppController()
{
    stopLiveUpdates();
}

// ─── Signal bağlantıları ─────────────────────────────────────────────────────
void AppController::connectApiSignals()
{
    // Roblox API cavabları
    connect(robloxApi_.get(), &Api::RobloxApi::universeInfoReady,
            this, [this](const Api::UniverseInfo& info) {
        if (info.ok) {
            applyGameInfo(info);
        } else {
            statusText_ = "ERR";
            isLive_     = false;
            emit statusChanged();
            termModel_->appendLine("err", "[API]", "Xəta: " + info.error);
        }
    });

    connect(robloxApi_.get(), &Api::RobloxApi::activeServersReady,
            this, [this](int count) {
        dashModel_->setServerCount(count);
    });

    connect(robloxApi_.get(), &Api::RobloxApi::dataStoreKeysReady,
            this, [this](const QString& store, const QStringList& keys) {
        dsModel_->setKeys(store, keys);
    });

    connect(robloxApi_.get(), &Api::RobloxApi::dataStoreEntryReady,
            this, [this](const QString& key, const QJsonValue& val) {
        dsModel_->setEntryValue(key, val);
    });

    connect(robloxApi_.get(), &Api::RobloxApi::dataStoreEntryUpdated,
            this, [this](const QString& key, bool success) {
        showToast(success ? "✓ " + key + " yeniləndi" : "✗ Yeniləmə uğursuz",
                  success ? "success" : "error");
    });

    connect(robloxApi_.get(), &Api::RobloxApi::messagePublished,
            this, [this](bool ok, const QString& err) {
        showToast(ok ? "✓ Elan göndərildi" : "✗ " + err,
                  ok ? "success" : "error");
    });

    connect(robloxApi_.get(), &Api::RobloxApi::terminalLog,
            this, [this](const QString& lvl, const QString& tag, const QString& msg) {
        termModel_->appendLine(lvl, tag, msg);
    });

    // Claude AI cavabları
    connect(anthropicApi_.get(), &Api::AnthropicApi::replyReady,
            this, [this](const QString& text) {
        aiModel_->addAssistantMessage(text);
    });

    connect(anthropicApi_.get(), &Api::AnthropicApi::thinkingChanged,
            this, [this](bool thinking) {
        aiModel_->setThinking(thinking);
    });

    // Live timer
    connect(liveTimer_, &QTimer::timeout, this, &AppController::refreshAllData);
}

// ─── Saxlanmış etimadnamələri yüklə (auto-login) ─────────────────────────────
// JS-dəki init() funksiyasının auto-login hissəsi
void AppController::loadSavedCredentials()
{
    auto& storage = Crypto::SecureStorage::instance();

    const auto savedKey = storage.load("apikey");
    const auto savedUid = storage.load("uid");

    if (savedKey && savedUid && !savedKey->isEmpty() && !savedUid->isEmpty()) {
        apiKey_     = *savedKey;
        universeId_ = *savedUid;
        const auto savedPid = storage.load("pid");
        if (savedPid) placeId_ = *savedPid;

        // Yüklənmiş dil
        const auto savedLang = storage.load("lang");
        if (savedLang && translator_->isValidLang(*savedLang)) {
            currentLang_ = *savedLang;
            translator_->setLang(*savedLang);
        }

        initMainApp();
    }
}

void AppController::initMainApp()
{
    isLoggedIn_ = true;
    robloxApi_->setCredentials(apiKey_, universeId_, placeId_);
    emit loginStateChanged();
    emit credentialsChanged();

    initTerminal();
    refreshAllData();
    startLiveUpdates();
}

void AppController::initTerminal()
{
    termModel_->appendLine("sys", "[SYS]", "ROStudio v5 — CyberWeld | AES-256 aktiv");
    termModel_->appendLine("ok",  "[AUTH]","API açarı doğrulandı — Universe: " + universeId_);
}

// ─── doLogin ─────────────────────────────────────────────────────────────────
// JS: async function doLogin() { ... showMainApp(gameInfo); }
void AppController::doLogin(const QString& apiKey,
                             const QString& universeId,
                             const QString& placeId)
{
    if (apiKey.trimmed().isEmpty() || universeId.trimmed().isEmpty()) {
        emit loginFailed(translator_->t("login-error-empty"));
        return;
    }
    if (apiKey.length() < 30) {
        emit loginFailed(translator_->t("login-error-short"));
        return;
    }

    apiKey_     = apiKey.trimmed();
    universeId_ = universeId.trimmed();
    placeId_    = placeId.trimmed();

    // Şifrəli saxla (JS: await secureStore('apikey', key))
    auto& st = Crypto::SecureStorage::instance();
    st.store("apikey", apiKey_);
    st.store("uid",    universeId_);
    if (!placeId_.isEmpty()) st.store("pid", placeId_);

    termModel_->appendLine("ok", "[AUTH]", "Etimadnamələr AES-256 ilə şifrələndi");
    initMainApp();
    emit loginSuccess();
}

// ─── doLogout ────────────────────────────────────────────────────────────────
// JS: function doLogout() { clearInterval(liveInterval); localStorage.removeItem... }
void AppController::doLogout()
{
    stopLiveUpdates();
    Crypto::SecureStorage::instance().clear();

    apiKey_.clear();
    universeId_.clear();
    placeId_.clear();
    isLoggedIn_ = false;
    visitHistory_.clear();

    dashModel_->reset();
    termModel_->clear();
    dsModel_->reset();
    aiModel_->reset();
    anthropicApi_->resetConversation();

    emit loginStateChanged();
    emit credentialsChanged();
}

// ─── saveNewCredentials ───────────────────────────────────────────────────────
// JS: async function saveNewAPI() { ... }
void AppController::saveNewCredentials(const QString& apiKey,
                                        const QString& universeId,
                                        const QString& placeId)
{
    auto& st = Crypto::SecureStorage::instance();
    if (!apiKey.isEmpty())     { apiKey_     = apiKey;     st.store("apikey", apiKey_); }
    if (!universeId.isEmpty()) { universeId_ = universeId; st.store("uid", universeId_); }
    if (!placeId.isEmpty())    { placeId_    = placeId;    st.store("pid", placeId_); }

    robloxApi_->setCredentials(apiKey_, universeId_, placeId_);
    emit credentialsChanged();
    showToast("✓ Yenidən qoşulunur...", "success");
    termModel_->appendLine("ok", "[API]", "Etimadnamələr yeniləndi — AES-256 yenidən şifrələndi");

    visitHistory_.clear();
    dashModel_->reset();
    refreshAllData();
}

// ─── switchPanel ─────────────────────────────────────────────────────────────
// JS: function switchPanel(name, btn) { ... }
void AppController::switchPanel(const QString& panelName)
{
    activePanel_ = panelName;
    emit activePanelChanged();

    if (panelName == "datastore" && !apiKey_.isEmpty()) {
        loadDataStore();
    }
}

// ─── refreshAllData ───────────────────────────────────────────────────────────
// JS: async function refreshAllData() { fetchPlayersOnline(); fetchActiveServers(); }
void AppController::refreshAllData()
{
    robloxApi_->fetchUniverseInfo();
    if (!placeId_.isEmpty()) {
        robloxApi_->fetchActiveServers();
    }
}

void AppController::applyGameInfo(const Api::UniverseInfo& info)
{
    // Visit tarixçəsi (qrafik üçün, JS: visitHistory.push/shift)
    visitHistory_.append(info.playing);
    if (visitHistory_.size() > 7) visitHistory_.removeFirst();

    dashModel_->update(info, visitHistory_);
    statusText_ = "LIVE";
    isLive_     = true;
    emit statusChanged();
}

void AppController::startLiveUpdates()
{
    if (!liveTimer_->isActive()) liveTimer_->start();
}

void AppController::stopLiveUpdates()
{
    liveTimer_->stop();
}

// ─── Terminal komandaları ─────────────────────────────────────────────────────
// JS: function sendTermCmd() { ... } switch(cmd) { case 'help': ... }
void AppController::sendTerminalCommand(const QString& rawCmd)
{
    const QString cmd = rawCmd.trimmed().toLower();
    if (cmd.isEmpty()) return;

    termModel_->appendLine("info", "$ ", rawCmd);

    if (cmd == "help" || cmd == "?") {
        termModel_->appendLine("ok", "[HELP]",
            "Əmrlər: help, status, refresh, clear, ping, uid, version, logout, theme");
    }
    else if (cmd == "status") {
        termModel_->appendLine("ok", "[SYS]",
            QString("Universe: %1 | Panel: %2 | AES: aktiv")
            .arg(universeId_, activePanel_));
    }
    else if (cmd == "refresh") {
        termModel_->appendLine("ok", "[SYS]", "Yenilənir...");
        refreshAllData();
    }
    else if (cmd == "clear") {
        clearTerminal();
    }
    else if (cmd == "ping") {
        termModel_->appendLine("ok", "[NET]", "pong — Roblox API müştərisi hazırdır");
    }
    else if (cmd == "uid") {
        termModel_->appendLine("ok", "[SYS]", "Universe ID: " + universeId_);
    }
    else if (cmd == "version") {
        termModel_->appendLine("ok", "[SYS]", "ROStudio v5.0.0 — CyberWeld");
    }
    else if (cmd == "logout") {
        doLogout();
    }
    else if (cmd.startsWith("say ")) {
        const QString msg = rawCmd.mid(4);
        robloxApi_->publishMessage("global", msg);
    }
    else {
        termModel_->appendLine("warn", "[ERR]",
            "Naməlum əmr: '" + rawCmd + "' — 'help' yazın");
    }
}

void AppController::clearTerminal()
{
    termModel_->clear();
    termModel_->appendLine("sys", "[SYS]", "Terminal təmizləndi");
}

// ─── DataStore ────────────────────────────────────────────────────────────────
void AppController::loadDataStore(const QString& storeName)
{
    robloxApi_->fetchDataStoreKeys(storeName);
}

// ─── AI Chat ─────────────────────────────────────────────────────────────────
void AppController::sendAiMessage(const QString& text)
{
    if (text.trimmed().isEmpty()) return;
    aiModel_->addUserMessage(text);

    Api::GameContext ctx;
    ctx.name    = dashModel_->gameName();
    ctx.players = dashModel_->playerCount();
    ctx.visits  = dashModel_->visitCount();

    anthropicApi_->sendMessage(text, ctx);
}

// ─── Elan ────────────────────────────────────────────────────────────────────
void AppController::sendAnnouncement(const QString& text,
                                      const QString& target,
                                      const QString& schedType)
{
    if (text.trimmed().isEmpty()) return;
    const QString topic = "announce_" + target;
    robloxApi_->publishMessage(topic, text);
    announceModel_->addHistoryEntry(text, target, schedType);
}

// ─── Toast ────────────────────────────────────────────────────────────────────
void AppController::showToast(const QString& msg, const QString& type)
{
    toastMsg_  = msg;
    toastType_ = type;
    emit toastRequested();
}

// ─── Dil ─────────────────────────────────────────────────────────────────────
void AppController::setLanguage(const QString& code)
{
    if (!translator_->isValidLang(code)) return;
    currentLang_ = code;
    translator_->setLang(code);
    Crypto::SecureStorage::instance().store("lang", code);
    emit langChanged();
}

// ─── Masked API Key ───────────────────────────────────────────────────────────
QString AppController::maskedApiKey() const
{
    if (apiKey_.isEmpty()) return "rblx_••••••••••••••••";
    return apiKey_.left(8) + "••••••••••••";
}

// ─── formatBigNum ─────────────────────────────────────────────────────────────
// JS: function formatBigNum(n) { if(n>=1e9) return (n/1e9).toFixed(1)+'B'; ... }
QString AppController::formatBigNum(qint64 n) const
{
    if (n >= 1'000'000'000LL)
        return QString::number(n / 1'000'000'000.0, 'f', 1) + "B";
    if (n >= 1'000'000LL)
        return QString::number(n / 1'000'000.0, 'f', 1) + "M";
    if (n >= 1'000LL)
        return QString::number(n / 1'000.0, 'f', 1) + "K";
    return QString::number(n);
}
