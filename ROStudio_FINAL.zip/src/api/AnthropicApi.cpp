// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — AnthropicApi.cpp
//  Claude AI inteqrasiyası
// ═══════════════════════════════════════════════════════════════════════════════
#include "AnthropicApi.h"
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QDebug>

namespace Api {

// ─── Sistem promptu (JS-dəki AI_SYSTEM sabitidir) ────────────────────────────
const char* AnthropicApi::SYSTEM_PROMPT = R"(
You are ROStudio AI, an expert assistant created by CyberWeld for Roblox game developers.

Your expertise:
1. LUAU (Roblox's scripting language) — full expert including:
   - Strict type system: local x: number = 5, function foo(p: Player): string
   - Modern APIs: task.wait(), task.spawn(), task.defer() instead of old wait()/spawn()
   - Roblox services: Players, DataStoreService, TweenService, RunService, HttpService, etc.
   - OOP patterns, Metatables, Modules
   - RemoteEvents/RemoteFunctions for client-server communication
   - DataStore2, ProfileService patterns
   - Knit, Rodux framework patterns
   - Raycasting, CFrame math, Vector3 operations
   - Game optimization: memory management, streaming, LOD

2. ROBLOX OPEN CLOUD API — knows all endpoints
3. GAME ANALYTICS — player retention, revenue, error analysis
4. SECURITY — anti-exploit patterns, server-side validation

Language: Always respond in the same language the user writes in. You know 150 languages fluently.

When teaching Luau, always:
- Use modern task.* APIs (never old wait/spawn)
- Add type annotations in Strict mode
- Show complete, working code examples
- Explain each line briefly
- Warn about common pitfalls

Creator: CyberWeld (Roblox username: CyberWeld)
App: ROStudio — professional mobile Roblox developer tool

Current game context will be provided when available.
)";

// ─── Constructor ─────────────────────────────────────────────────────────────
AnthropicApi::AnthropicApi(QObject* parent) : QObject(parent) {}

void AnthropicApi::resetConversation()
{
    history_ = QJsonArray();
}

// ─── sendMessage ─────────────────────────────────────────────────────────────
// JS-dəki callClaudeAI(userMsg, gameContext) funksiyasının qarşılığı
void AnthropicApi::sendMessage(const QString& userText, const GameContext& ctx)
{
    emit thinkingChanged(true);

    // Kontekst əlavəsi
    QString fullText = userText;
    if (!ctx.name.isEmpty()) {
        fullText += QString("\n\n[Current game: %1, %2 players online, %3 total visits]")
            .arg(ctx.name).arg(ctx.players).arg(ctx.visits);
    }

    // Söhbət tarixçəsinə əlavə et
    QJsonObject userMsg;
    userMsg["role"]    = "user";
    userMsg["content"] = fullText;
    history_.append(userMsg);

    // Son 20 mesajı saxla (JS: if (aiMessages.length > 20) aiMessages.slice(-20))
    while (history_.size() > MAX_HISTORY) {
        history_.removeFirst();
    }

    // API sorğusu hazırla
    QJsonObject body;
    body["model"]      = MODEL;
    body["max_tokens"] = 1000;
    body["system"]     = SYSTEM_PROMPT;
    body["messages"]   = history_;

    QNetworkRequest req(QUrl(API_URL));
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    // NOT: API açarı buraya əlavə edilməlidir
    // Tətbiqin parametrlərindən alınır
    // req.setRawHeader("x-api-key", anthropicApiKey.toUtf8());
    req.setRawHeader("anthropic-version", "2023-06-01");
    req.setTransferTimeout(30000);

    const QByteArray bodyBytes = QJsonDocument(body).toJson(QJsonDocument::Compact);
    QNetworkReply* reply = nam_.post(req, bodyBytes);

    connect(reply, &QNetworkReply::finished, this, [this, reply, userText, ctx]() {
        reply->deleteLater();
        emit thinkingChanged(false);

        if (reply->error() != QNetworkReply::NoError) {
            // Offline fallback (JS-dəki getOfflineFallback() kimi)
            const QString fallback = offlineFallback(userText, ctx);
            emit replyReady(fallback);
            return;
        }

        const QByteArray data = reply->readAll();
        const QJsonDocument doc = QJsonDocument::fromJson(data);
        const QJsonObject   obj = doc.object();

        // data.content[].text birləşdir (JS-dəki kimi)
        QString text;
        if (obj.contains("content")) {
            for (const auto& block : obj["content"].toArray()) {
                const auto b = block.toObject();
                if (b["type"].toString() == "text") {
                    text += b["text"].toString();
                }
            }
        } else if (obj.contains("error")) {
            text = "API Xətası: " + obj["error"].toObject()["message"].toString();
        } else {
            text = offlineFallback(userText, ctx);
        }

        if (text.isEmpty()) {
            text = offlineFallback(userText, ctx);
        }

        // Tarixçəyə assistant cavabını əlavə et
        QJsonObject assistantMsg;
        assistantMsg["role"]    = "assistant";
        assistantMsg["content"] = text;
        history_.append(assistantMsg);

        emit replyReady(text);
    });
}

// ─── Offline Fallback ─────────────────────────────────────────────────────────
// JS-dəki getOfflineFallback() funksiyasının tam C++ qarşılığı
QString AnthropicApi::offlineFallback(const QString& query, const GameContext& ctx)
{
    const QString ql = query.toLower();
    const QString ctxStr = QString("Oyun: %1 | Oyunçular: %2 | Ziyarətlər: %3")
        .arg(ctx.name.isEmpty() ? "Naməlum" : ctx.name)
        .arg(ctx.players)
        .arg(ctx.visits);

    // Luau / scripting sualları
    if (ql.contains("lua") || ql.contains("luau") || ql.contains("script") ||
        ql.contains("kod") || ql.contains("code")) {
        return
            "**Luau haqqında (Offline rejim)**\n\n"
            "Müasir Luau nümunəsi:\n"
            "```lua\n"
            "-- Strict mode tip annotasiyası\n"
            "local function greetPlayer(player: Player): string\n"
            "   local name: string = player.DisplayName\n"
            "   return \"Salam, \" .. name .. \"!\"\n"
            "end\n\n"
            "-- Müasir task API (köhnə wait() YOX)\n"
            "local Players = game:GetService(\"Players\")\n\n"
            "Players.PlayerAdded:Connect(function(player: Player)\n"
            "   task.delay(1, function()\n"
            "      local msg = greetPlayer(player)\n"
            "      print(msg)\n"
            "   end)\n"
            "end)\n"
            "```\n\n"
            "Nə öyrənmək istəyirsiniz? DataStore, RemoteEvents, TweenService?";
    }

    // Oyunçu / statistika sualları
    if (ql.contains("player") || ql.contains("oyunçu") || ql.contains("drop")) {
        return QString(
            "**Oyunçu Analitikası (Offline rejim)**\n\n"
            "%1\n\n"
            "Oyunçu azalması (player drop) üçün yoxlayın:\n"
            "• Loading vaxtı — 10+ saniyədirsə kritikdir\n"
            "• Crash-lar — Output-da baxın\n"
            "• Oyun balansı — çox çətin/asan?\n"
            "• Tutorial yoxluğu — yeni oyunçular itir?\n\n"
            "Statistika almaq üçün Game Analytics inteqrasiyasını tövsiyə edirəm.").arg(ctxStr);
    }

    // DataStore sualları
    if (ql.contains("datastore") || ql.contains("data")) {
        return
            "**DataStore Nümunəsi (Offline rejim)**\n\n"
            "```lua\n"
            "local DataStoreService = game:GetService(\"DataStoreService\")\n"
            "local playerData = DataStoreService:GetDataStore(\"PlayerData\")\n\n"
            "-- Məlumat saxla\n"
            "local function saveData(player: Player, data: {})\n"
            "   local success, err = pcall(function()\n"
            "      playerData:SetAsync(tostring(player.UserId), data)\n"
            "   end)\n"
            "   if not success then\n"
            "      warn(\"DataStore xətası:\", err)\n"
            "   end\n"
            "end\n"
            "```\n\n"
            "ProfileService istifadəsini tövsiyə edirəm — daha etibarlıdır.";
    }

    // Ümumi cavab
    return QString(
        "**ROStudio AI (Offline rejim)**\n\n"
        "Hal-hazırda internet bağlantısı yoxdur. Məhdud cavablar verə bilərəm.\n\n"
        "%1\n\n"
        "Sualınız: %2\n\n"
        "İnternet bağlandıqda tam cavab alacaqsınız.").arg(ctxStr, query);
}

} // namespace Api
