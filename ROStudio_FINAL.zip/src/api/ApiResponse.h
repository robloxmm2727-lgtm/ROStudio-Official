#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — ApiResponse.h
//  API cavab strukturları (JS-dəki obyekt literallarının C++ qarşılığı)
// ═══════════════════════════════════════════════════════════════════════════════
#include <QString>
#include <QJsonValue>
#include <QStringList>

namespace Api {

/// JS-dəki fetchPlayersOnline() cavabının C++ qarşılığı
struct UniverseInfo {
    bool    ok          = false;
    QString name;
    int     playing     = 0;       // activePlayerCount
    int64_t visits      = 0;       // totalVisitCount
    int     maxPlayers  = 0;
    int     latencyMs   = 0;
    QString error;
};

/// DataStore girişi
struct DataStoreEntry {
    QString    key;
    QJsonValue value;
    QString    type;   // "number", "string", "table", "boolean"
};

/// Mesaj göndərmə nəticəsi
struct PublishResult {
    bool    ok = false;
    QString error;
};

} // namespace Api
