#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — AnthropicApi.h
//  Claude AI çağırışı (JS-dəki callClaudeAI() funksiyasının C++ qarşılığı)
//  Çoxsaylı söhbət tarixçəsi (aiMessages[]) saxlanılır
// ═══════════════════════════════════════════════════════════════════════════════
#include <QObject>
#include <QString>
#include <QNetworkAccessManager>
#include <QJsonArray>

namespace Api {

struct GameContext {
    QString name;
    int     players = 0;
    int64_t visits  = 0;
};

class AnthropicApi : public QObject {
    Q_OBJECT

public:
    explicit AnthropicApi(QObject* parent = nullptr);

    /// Söhbəti sıfırla (logout zamanı)
    void resetConversation();

    /// AI-a mesaj göndər (asinxron)
    void sendMessage(const QString& userText,
                     const GameContext& ctx = {});

    /// Offline fallback cavabı (şəbəkəsiz rejim)
    static QString offlineFallback(const QString& query,
                                   const GameContext& ctx);

signals:
    void replyReady(const QString& text);
    void errorOccurred(const QString& errorMsg);
    void thinkingChanged(bool isThinking);

private:
    QNetworkAccessManager nam_;
    QJsonArray            history_;        // JS aiMessages[]
    static constexpr int  MAX_HISTORY = 20;

    static const char* SYSTEM_PROMPT;
    static constexpr const char* API_URL =
        "https://api.anthropic.com/v1/messages";
    static constexpr const char* MODEL =
        "claude-sonnet-4-20250514";
};

} // namespace Api
