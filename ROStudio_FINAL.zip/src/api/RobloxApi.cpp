// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — RobloxApi.cpp
//  Roblox Open Cloud API müştərisi — QtNetwork ilə
// ═══════════════════════════════════════════════════════════════════════════════
#include "RobloxApi.h"
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrl>
#include <QTimer>
#include <QDebug>

namespace Api {

RobloxApi::RobloxApi(QObject* parent) : QObject(parent)
{
    // SSL sertifikat xətalarını yumşat (mobil/masa üstü üçün)
    // nam_.setSslConfiguration(QSslConfiguration::defaultConfiguration());
}

void RobloxApi::setCredentials(const QString& apiKey,
                                const QString& universeId,
                                const QString& placeId)
{
    apiKey_     = apiKey;
    universeId_ = universeId;
    placeId_    = placeId;
}

// ─── Ümumi GET köməkçisi ──────────────────────────────────────────────────────
void RobloxApi::get(const QString& endpoint,
                    std::function<void(const QJsonDocument&, int)> onSuccess,
                    std::function<void(int, const QString&)> onError)
{
    const QUrl url(QString(BASE_URL) + endpoint);
    QNetworkRequest req(url);
    req.setRawHeader("x-api-key", apiKey_.toUtf8());
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    req.setTransferTimeout(10000); // 10 saniyə timeout (JS AbortController kimi)

    QNetworkReply* reply = nam_.get(req);
    connect(reply, &QNetworkReply::finished, this, [=]() {
        reply->deleteLater();
        const int statusCode = reply->attribute(
            QNetworkRequest::HttpStatusCodeAttribute).toInt();

        if (reply->error() != QNetworkReply::NoError) {
            emit networkError(endpoint, reply->errorString());
            onError(-1, reply->errorString());
            return;
        }

        const QByteArray body = reply->readAll();
        const QJsonDocument doc = QJsonDocument::fromJson(body);

        if (statusCode >= 200 && statusCode < 300) {
            onSuccess(doc, statusCode);
        } else {
            const QString errMsg = doc.object()["message"].toString(
                "HTTP " + QString::number(statusCode));
            onError(statusCode, errMsg);
        }
    });
}

// ─── Ümumi POST/PATCH köməkçisi ───────────────────────────────────────────────
void RobloxApi::post(const QString& endpoint,
                     const QByteArray& body,
                     const QString& method,
                     std::function<void(const QJsonDocument&, int)> onSuccess,
                     std::function<void(int, const QString&)> onError)
{
    const QUrl url(QString(BASE_URL) + endpoint);
    QNetworkRequest req(url);
    req.setRawHeader("x-api-key", apiKey_.toUtf8());
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    req.setTransferTimeout(10000);

    QNetworkReply* reply = nullptr;
    if (method == "POST")       reply = nam_.post(req, body);
    else if (method == "PATCH") reply = nam_.sendCustomRequest(req, "PATCH", body);
    else                        reply = nam_.post(req, body);

    connect(reply, &QNetworkReply::finished, this, [=]() {
        reply->deleteLater();
        const int statusCode = reply->attribute(
            QNetworkRequest::HttpStatusCodeAttribute).toInt();

        if (reply->error() != QNetworkReply::NoError) {
            emit networkError(endpoint, reply->errorString());
            onError(-1, reply->errorString());
            return;
        }

        const QByteArray respBody = reply->readAll();
        const QJsonDocument doc = QJsonDocument::fromJson(respBody);

        if (statusCode >= 200 && statusCode < 300) {
            onSuccess(doc, statusCode);
        } else {
            const QString errMsg = doc.object()["message"].toString(
                "HTTP " + QString::number(statusCode));
            onError(statusCode, errMsg);
        }
    });
}

// ─── fetchUniverseInfo ────────────────────────────────────────────────────────
// JS: fetch(`https://apis.roblox.com/cloud/v2/universes/${universeId}`)
void RobloxApi::fetchUniverseInfo()
{
    const QString endpoint = QString("/universes/%1").arg(universeId_);
    emit terminalLog("info", "[API]", "Universe məlumatı alınır...");

    get(endpoint,
        [this, endpoint](const QJsonDocument& doc, int /*status*/) {
            const QJsonObject obj = doc.object();
            UniverseInfo info;
            info.ok       = true;
            info.name     = obj["displayName"].toString(
                                obj["name"].toString("Universe " + universeId_));
            info.playing  = obj["activePlayerCount"].toInt(
                                obj["playing"].toInt(0));
            info.visits   = static_cast<int64_t>(
                                obj["totalVisitCount"].toDouble(
                                    obj["visits"].toDouble(0)));
            info.maxPlayers = obj["maxPlayers"].toInt(0);
            emit terminalLog("ok", "[API]",
                QString("%1 · %2 online · %3 ziyarət")
                .arg(info.name).arg(info.playing).arg(info.visits));
            emit universeInfoReady(info);
        },
        [this, endpoint](int code, const QString& msg) {
            emit terminalLog("err", "[API]", "Universe xətası: " + msg);
            UniverseInfo info;
            info.ok = false;
            info.error = msg;
            emit apiError("fetchUniverseInfo", code, msg);
            emit universeInfoReady(info);
        }
    );
}

// ─── fetchActiveServers ───────────────────────────────────────────────────────
// JS: fetch(`/universes/${uid}/places/${pid}/instances`)
void RobloxApi::fetchActiveServers()
{
    if (placeId_.isEmpty()) return;
    const QString endpoint = QString("/universes/%1/places/%2/instances")
        .arg(universeId_, placeId_);

    get(endpoint,
        [this](const QJsonDocument& doc, int) {
            const QJsonObject obj = doc.object();
            int count = 0;
            if (obj.contains("instances"))
                count = obj["instances"].toArray().size();
            else if (obj.contains("gameServerInstances"))
                count = obj["gameServerInstances"].toArray().size();
            else
                count = obj["totalResults"].toInt(0);
            emit activeServersReady(count);
        },
        [this](int code, const QString& msg) {
            emit apiError("fetchActiveServers", code, msg);
        }
    );
}

// ─── fetchDataStoreKeys ───────────────────────────────────────────────────────
// JS: fetch(`/universes/${uid}/data-stores/${storeName}/entries`)
void RobloxApi::fetchDataStoreKeys(const QString& storeName)
{
    const QString endpoint = QString("/universes/%1/data-stores/%2/entries")
        .arg(universeId_, storeName);
    emit terminalLog("info", "[DS]", "Yüklənir: " + storeName);

    get(endpoint,
        [this, storeName](const QJsonDocument& doc, int) {
            const QJsonObject obj = doc.object();
            QStringList keys;
            auto parseKeys = [&](const QJsonArray& arr) {
                for (const auto& item : arr) {
                    if (item.isString()) {
                        keys << item.toString();
                    } else if (item.isObject()) {
                        const auto o = item.toObject();
                        keys << o["key"].toString(
                                   o["entryKey"].toString(
                                       QJsonDocument(o).toJson(QJsonDocument::Compact)));
                    }
                }
            };
            if (obj.contains("keys"))    parseKeys(obj["keys"].toArray());
            else if (obj.contains("entries")) parseKeys(obj["entries"].toArray());

            emit terminalLog("ok", "[DS]", QString("%1 açar yükləndi").arg(keys.size()));
            emit dataStoreKeysReady(storeName, keys);
        },
        [this, storeName](int code, const QString& msg) {
            emit terminalLog("err", "[DS]", msg);
            emit apiError("fetchDataStoreKeys", code, msg);
            emit dataStoreKeysReady(storeName, {});
        }
    );
}

// ─── fetchDataStoreEntry ──────────────────────────────────────────────────────
void RobloxApi::fetchDataStoreEntry(const QString& storeName, const QString& key)
{
    const QString encoded  = QUrl::toPercentEncoding(key);
    const QString endpoint = QString("/universes/%1/data-stores/%2/entries/%3")
        .arg(universeId_, storeName, encoded);

    get(endpoint,
        [this, key](const QJsonDocument& doc, int) {
            const QJsonObject obj = doc.object();
            const QJsonValue  val = obj.contains("value") ? obj["value"] : QJsonValue(obj);
            emit dataStoreEntryReady(key, val);
        },
        [this](int code, const QString& msg) {
            emit apiError("fetchDataStoreEntry", code, msg);
        }
    );
}

// ─── updateDataStoreEntry ─────────────────────────────────────────────────────
void RobloxApi::updateDataStoreEntry(const QString& storeName,
                                      const QString& key,
                                      const QJsonValue& value)
{
    const QString encoded  = QUrl::toPercentEncoding(key);
    const QString endpoint = QString("/universes/%1/data-stores/%2/entries/%3")
        .arg(universeId_, storeName, encoded);

    QJsonObject body;
    body["value"] = value;
    const QByteArray bodyBytes = QJsonDocument(body).toJson(QJsonDocument::Compact);

    post(endpoint, bodyBytes, "PATCH",
        [this, key](const QJsonDocument&, int) {
            emit terminalLog("ok", "[DS]", key + " yeniləndi");
            emit dataStoreEntryUpdated(key, true);
        },
        [this, key](int code, const QString& msg) {
            emit terminalLog("err", "[DS]", "Yeniləmə xətası: " + msg);
            emit dataStoreEntryUpdated(key, false);
            emit apiError("updateDataStoreEntry", code, msg);
        }
    );
}

// ─── publishMessage ───────────────────────────────────────────────────────────
// JS: POST `/universes/${uid}/topics/${topic}` { message: msg }
void RobloxApi::publishMessage(const QString& topic, const QString& message)
{
    const QString endpoint = QString("/universes/%1/topics/%2")
        .arg(universeId_, topic);

    QJsonObject body;
    body["message"] = message;

    post(endpoint, QJsonDocument(body).toJson(QJsonDocument::Compact), "POST",
        [this](const QJsonDocument&, int) {
            emit terminalLog("ok", "[MSG]", "Mesaj göndərildi");
            emit messagePublished(true, {});
        },
        [this](int code, const QString& msg) {
            emit terminalLog("warn", "[MSG]", "Göndərmə xətası: " + msg);
            emit messagePublished(false, msg);
            emit apiError("publishMessage", code, msg);
        }
    );
}

} // namespace Api
