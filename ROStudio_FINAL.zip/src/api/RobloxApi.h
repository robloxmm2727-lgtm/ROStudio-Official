#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — RobloxApi.h
//  Roblox Open Cloud REST API müştərisi
//  JS-dəki: apiFetch(), fetchPlayersOnline(), fetchDSKeys() və s.
//  Thread-safe: bütün şəbəkə sorğuları ayrı thread-də icra edilir
// ═══════════════════════════════════════════════════════════════════════════════
#include "ApiResponse.h"
#include <QObject>
#include <QString>
#include <QNetworkAccessManager>
#include <functional>

namespace Api {

class RobloxApi : public QObject {
    Q_OBJECT

public:
    explicit RobloxApi(QObject* parent = nullptr);

    /// Sessiya parametrlərini yenilə
    void setCredentials(const QString& apiKey,
                        const QString& universeId,
                        const QString& placeId);

    // ─── Endpoint çağırışları (async, signal ilə cavab) ─────────────────────

    /// GET universes/{uid} → oyun adı, oyunçu sayı, ziyarət sayı
    void fetchUniverseInfo();

    /// GET universes/{uid}/places/{pid}/instances → server sayı
    void fetchActiveServers();

    /// GET universes/{uid}/data-stores/{name}/entries → açar siyahısı
    void fetchDataStoreKeys(const QString& storeName);

    /// GET .../entries/{key} → dəyər
    void fetchDataStoreEntry(const QString& storeName, const QString& key);

    /// PATCH .../entries/{key} → dəyəri yenilə
    void updateDataStoreEntry(const QString& storeName,
                              const QString& key,
                              const QJsonValue& value);

    /// POST universes/{uid}/topics/{topic} → mesaj göndər
    void publishMessage(const QString& topic, const QString& message);

signals:
    // ─── Uğurlu cavablar ────────────────────────────────────────────────────
    void universeInfoReady(const UniverseInfo& info);
    void activeServersReady(int serverCount);
    void dataStoreKeysReady(const QString& storeName, const QStringList& keys);
    void dataStoreEntryReady(const QString& key, const QJsonValue& value);
    void dataStoreEntryUpdated(const QString& key, bool success);
    void messagePublished(bool success, const QString& error);

    // ─── Xəta siqnalları ───────────────────────────────────────────────────
    void apiError(const QString& context, int statusCode, const QString& message);
    void networkError(const QString& context, const QString& message);

    /// Gizli siqnal: terminal üçün log
    void terminalLog(const QString& level, const QString& tag, const QString& msg);

private:
    /// Ümumi HTTP GET sorğusu
    void get(const QString& endpoint,
             std::function<void(const QJsonDocument&, int)> onSuccess,
             std::function<void(int, const QString&)> onError);

    /// Ümumi HTTP PATCH/POST sorğusu
    void post(const QString& endpoint,
              const QByteArray& body,
              const QString& method,
              std::function<void(const QJsonDocument&, int)> onSuccess,
              std::function<void(int, const QString&)> onError);

    QNetworkAccessManager nam_;
    QString apiKey_;
    QString universeId_;
    QString placeId_;

    static constexpr const char* BASE_URL = "https://apis.roblox.com/cloud/v2";
};

} // namespace Api
