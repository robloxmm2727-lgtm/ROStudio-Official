// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — Translator.cpp
//  JS-dəki LANGS{} sabitinin C++ implementasiyası
// ═══════════════════════════════════════════════════════════════════════════════
#include "Translator.h"

Translator::Translator(QObject* parent) : QObject(parent)
{
    loadBuiltinLangs();
}

QString Translator::t(const QString& key) const
{
    const auto& lang = langs_.value(currentLang_);
    if (lang.contains(key)) return lang[key];
    const auto& en = langs_.value("en");
    if (en.contains(key)) return en[key];
    return key;
}

void Translator::setLang(const QString& code)
{
    if (!langs_.contains(code)) return;
    currentLang_ = code;
    emit langChanged();
}

bool Translator::isValidLang(const QString& code) const
{
    return langs_.contains(code);
}

QStringList Translator::allLangCodes() const
{
    return langs_.keys();
}

// ─── Dil əlavəsi köməkçisi ────────────────────────────────────────────────────
void Translator::loadBuiltinLangs()
{
    // ── İngilis ───────────────────────────────────────────────────────────────
    langs_["en"] = {
        {"lg-tagline",       "Mobile Roblox Developer Tool"},
        {"lg-card-title",    "Credentials"},
        {"lg-lbl-apikey",    "ROBLOX API KEY"},
        {"lg-lbl-uid",       "UNIVERSE ID"},
        {"lg-lbl-pid",       "PLACE ID"},
        {"lg-security",      "AES-256 encrypted · Stored locally only · Zero cloud leakage"},
        {"btn-login-text",   "Log In"},
        {"nav-dashboard",    "Dashboard"},
        {"nav-terminal",     "Terminal"},
        {"nav-datastore",    "DataStore"},
        {"nav-ai",           "AI"},
        {"nav-announce",     "Announce"},
        {"nav-collab",       "Team"},
        {"nav-settings",     "Settings"},
        {"stat-players",     "Active Players"},
        {"stat-robux",       "Robux Today"},
        {"stat-visits",      "Total Visits"},
        {"stat-errors",      "Errors"},
        {"stat-errors-sub",  "last hour"},
        {"sect-active-games","Active Games"},
        {"sect-weekly",      "Weekly Visits"},
        {"chart-visits-title","Visits per day"},
        {"chart-today",      "now"},
        {"chart-prev",       "prev"},
        {"gms-players",      "Players"},
        {"gms-servers",      "Servers"},
        {"gms-version",      "Version"},
        {"term-clear",       "CLEAR"},
        {"sect-player-data", "Player Data"},
        {"ai-greet",         "Hi! I'm ROStudio AI by CyberWeld. Ask me anything about Roblox!"},
        {"btn-send-announce","Send Announcement"},
        {"btn-logout",       "Logout & Clear Data"},
        {"login-error-empty","Please fill in API Key and Universe ID."},
        {"login-error-short","API Key seems too short. Check your credentials."},
        {"lang-name",        "English"},
        {"tb-status-text",   "LIVE"},
        {"sect-history",     "History"},
        {"sect-team",        "Team Members"},
        {"btn-invite",       "+ Invite Collaborator"},
        {"set-api-sect",     "API Configuration"},
        {"set-current-key",  "Current API Key"},
        {"set-uid",          "Universe ID"},
        {"btn-change-api",   "Change API Key"},
        {"set-prefs",        "Preferences"},
        {"set-lang",         "Language"},
        {"btn-save-api",     "Save & Reconnect"},
        {"modal-api-title",  "Update API Credentials"},
        {"modal-api-sub",    "Your data stays on-device (AES-256)"},
    };

    // ── Azərbaycan ────────────────────────────────────────────────────────────
    langs_["az"] = {
        {"lg-tagline",       "Mobil Roblox Tərtibatçı Aləti"},
        {"lg-card-title",    "Giriş məlumatları"},
        {"lg-lbl-apikey",    "ROBLOX API AÇARI"},
        {"lg-lbl-uid",       "UNIVERSE ID"},
        {"lg-lbl-pid",       "PLACE ID"},
        {"lg-security",      "AES-256 şifrələnmiş · Yalnız cihazda · Bulud sızması sıfır"},
        {"btn-login-text",   "Daxil ol"},
        {"nav-dashboard",    "İdarə paneli"},
        {"nav-terminal",     "Terminal"},
        {"nav-datastore",    "DataStore"},
        {"nav-ai",           "AI"},
        {"nav-announce",     "Elan"},
        {"nav-collab",       "Komanda"},
        {"nav-settings",     "Parametrlər"},
        {"stat-players",     "Aktiv Oyunçular"},
        {"stat-robux",       "Bu gün Robux"},
        {"stat-visits",      "Ümumi Ziyarət"},
        {"stat-errors",      "Xətalar"},
        {"stat-errors-sub",  "son saat"},
        {"sect-active-games","Aktiv Oyunlar"},
        {"sect-weekly",      "Həftəlik Ziyarətlər"},
        {"chart-visits-title","Günlük ziyarətlər"},
        {"chart-today",      "indi"},
        {"chart-prev",       "əvvəl"},
        {"gms-players",      "Oyunçular"},
        {"gms-servers",      "Serverlər"},
        {"gms-version",      "Versiya"},
        {"term-clear",       "TƏMİZLƏ"},
        {"sect-player-data", "Oyunçu Datası"},
        {"ai-greet",         "Salam! Mən CyberWeld-in ROStudio AI-yəm. Roblox haqqında hər şeyi soruşun!"},
        {"btn-send-announce","Elanı Göndər"},
        {"btn-logout",       "Çıxış & Məlumatları Sil"},
        {"login-error-empty","Zəhmət olmasa API Açarı və Universe ID daxil edin."},
        {"login-error-short","API Açarı çox qısa görünür. Etibarlı məlumatları yoxlayın."},
        {"lang-name",        "Azərbaycanca"},
        {"tb-status-text",   "CAN"},
        {"sect-history",     "Tarixçə"},
        {"sect-team",        "Komanda Üzvləri"},
        {"btn-invite",       "+ Əməkdaş Dəvət et"},
        {"set-api-sect",     "API Konfiqurasiyası"},
        {"set-current-key",  "Hazırkı API Açarı"},
        {"set-uid",          "Universe ID"},
        {"btn-change-api",   "API Açarını Dəyişdir"},
        {"set-prefs",        "Üstünlüklər"},
        {"set-lang",         "Dil"},
        {"btn-save-api",     "Saxla & Yenidən Qoş"},
        {"modal-api-title",  "API Etimadnamələrini Yenilə"},
        {"modal-api-sub",    "Məlumatınız cihazda qalır (AES-256)"},
    };

    // ── Türk ─────────────────────────────────────────────────────────────────
    langs_["tr"] = {
        {"lg-tagline",       "Mobil Roblox Geliştirici Aracı"},
        {"lg-card-title",    "Giriş bilgileri"},
        {"lg-lbl-apikey",    "ROBLOX API ANAHTARI"},
        {"lg-lbl-uid",       "UNIVERSE ID"},
        {"lg-lbl-pid",       "PLACE ID"},
        {"lg-security",      "AES-256 şifreli · Yalnızca cihazda · Sıfır bulut sızıntısı"},
        {"btn-login-text",   "Giriş Yap"},
        {"nav-dashboard",    "Pano"},
        {"nav-terminal",     "Terminal"},
        {"nav-datastore",    "DataStore"},
        {"nav-ai",           "Yapay Zeka"},
        {"nav-announce",     "Duyuru"},
        {"nav-collab",       "Ekip"},
        {"nav-settings",     "Ayarlar"},
        {"stat-players",     "Aktif Oyuncular"},
        {"stat-robux",       "Bugünkü Robux"},
        {"stat-visits",      "Toplam Ziyaret"},
        {"stat-errors",      "Hatalar"},
        {"stat-errors-sub",  "son saat"},
        {"sect-active-games","Aktif Oyunlar"},
        {"sect-weekly",      "Haftalık Ziyaretler"},
        {"chart-visits-title","Günlük ziyaretler"},
        {"chart-today",      "şimdi"},
        {"chart-prev",       "önce"},
        {"gms-players",      "Oyuncular"},
        {"gms-servers",      "Sunucular"},
        {"gms-version",      "Sürüm"},
        {"term-clear",       "TEMİZLE"},
        {"sect-player-data", "Oyuncu Verisi"},
        {"ai-greet",         "Merhaba! Ben CyberWeld'in ROStudio AI'yım. Roblox hakkında her şeyi sorun!"},
        {"btn-send-announce","Duyuru Gönder"},
        {"btn-logout",       "Çıkış & Verileri Sil"},
        {"login-error-empty","Lütfen API Anahtarı ve Universe ID girin."},
        {"login-error-short","API Anahtarı çok kısa görünüyor."},
        {"lang-name",        "Türkçe"},
        {"tb-status-text",   "CANLI"},
    };

    // ── Rus ───────────────────────────────────────────────────────────────────
    langs_["ru"] = {
        {"lg-tagline",       "Мобильный инструмент разработчика Roblox"},
        {"lg-card-title",    "Учётные данные"},
        {"lg-lbl-apikey",    "API КЛЮЧ ROBLOX"},
        {"lg-lbl-uid",       "UNIVERSE ID"},
        {"lg-lbl-pid",       "PLACE ID"},
        {"lg-security",      "AES-256 шифрование · Только на устройстве · Без облака"},
        {"btn-login-text",   "Войти"},
        {"nav-dashboard",    "Панель"},
        {"nav-terminal",     "Терминал"},
        {"nav-datastore",    "DataStore"},
        {"nav-ai",           "ИИ"},
        {"nav-announce",     "Объявл."},
        {"nav-collab",       "Команда"},
        {"nav-settings",     "Настройки"},
        {"stat-players",     "Активные игроки"},
        {"stat-robux",       "Robux сегодня"},
        {"stat-visits",      "Всего посещений"},
        {"stat-errors",      "Ошибки"},
        {"stat-errors-sub",  "за час"},
        {"sect-active-games","Активные игры"},
        {"sect-weekly",      "Посещения за неделю"},
        {"chart-visits-title","Посещений в день"},
        {"chart-today",      "сейчас"},
        {"chart-prev",       "ранее"},
        {"gms-players",      "Игроки"},
        {"gms-servers",      "Серверы"},
        {"gms-version",      "Версия"},
        {"term-clear",       "ОЧИСТИТЬ"},
        {"sect-player-data", "Данные игрока"},
        {"ai-greet",         "Привет! Я ROStudio AI от CyberWeld. Спрашивай о Roblox!"},
        {"btn-send-announce","Отправить объявление"},
        {"btn-logout",       "Выход & Очистка данных"},
        {"login-error-empty","Заполните API ключ и Universe ID."},
        {"login-error-short","API ключ слишком короткий."},
        {"lang-name",        "Русский"},
        {"tb-status-text",   "LIVE"},
    };
}
