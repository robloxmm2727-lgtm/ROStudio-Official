#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — Translator.h
//  JS-dəki LANGS{} obyektinin və t() funksiyasının C++ qarşılığı
//  Azərbaycan, İngilis, Rus, Türk və digər dillər dəstəklənir
// ═══════════════════════════════════════════════════════════════════════════════
#include <QObject>
#include <QString>
#include <QHash>
#include <QStringList>

class Translator : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString langCode READ langCode NOTIFY langChanged)

public:
    explicit Translator(QObject* parent = nullptr);

    /// JS: t(key) — cari dildəki mətni qaytar
    Q_INVOKABLE QString t(const QString& key) const;

    /// Dil kodu dəyişdir
    void setLang(const QString& code);

    QString     langCode()    const { return currentLang_; }
    bool        isValidLang(const QString& code) const;
    QStringList allLangCodes() const;

signals:
    void langChanged();

private:
    void loadBuiltinLangs();

    using LangMap = QHash<QString, QString>;
    QHash<QString, LangMap> langs_;   // langCode → (key → value)
    QString currentLang_ = "en";
};
