#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — SecureStorage.h
//  JS localStorage → C++ AES-256-GCM şifrələnmiş JSON faylı
//  Fayl yeri: ~/.config/ROStudio/secure.dat
// ═══════════════════════════════════════════════════════════════════════════════
#include <QString>
#include <QVariant>
#include <QJsonObject>
#include <optional>

namespace Crypto {

class SecureStorage {
public:
    static SecureStorage& instance();

    /// Məlumatı şifrəli saxla (JS: secureStore(k, v))
    bool store(const QString& key, const QString& value);

    /// Şifrəli məlumatı oxu (JS: secureLoad(k))
    std::optional<QString> load(const QString& key);

    /// Məlumatı sil (JS: localStorage.removeItem(k))
    void remove(const QString& key);

    /// Bütün məlumatları sil (logout)
    void clear();

    /// Fayl yolu qaytarır
    QString filePath() const;

private:
    SecureStorage();
    ~SecureStorage() = default;

    /// JSON-u yenidən diskə yaz (şifrəli)
    bool flushToDisk();

    /// Diskdən oxu (şifrəni aç)
    bool loadFromDisk();

    QJsonObject cache_;  // açıq JSON açar-dəyər cütü (yalnız yaddaşda)
    bool        loaded_ = false;
    QString     filePath_;
};

} // namespace Crypto
