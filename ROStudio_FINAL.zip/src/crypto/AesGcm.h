#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — AesGcm.h
//  AES-256-GCM şifrələmə/açma (WebCrypto AES-GCM-ə tam uyğun format)
//  JS-dəki: salt(16) || iv(12) || ciphertext formatını tam qoruyur
// ═══════════════════════════════════════════════════════════════════════════════

#include <QString>
#include <QByteArray>
#include <optional>

namespace Crypto {

/// Şifrələmə nəticəsi: base64-kodlanmış blob
/// Format: [16 byte PBKDF2 salt][12 byte AES-GCM IV][ciphertext + 16 byte GCM tag]
/// Bu format JS WebCrypto ilə tam uyğundur.
struct EncryptResult {
    QString base64Blob;
    bool    success = false;
    QString errorMsg;
};

struct DecryptResult {
    QString plaintext;
    bool    success = false;
    QString errorMsg;
};

class AesGcm {
public:
    /// Mətn şifrələ: PBKDF2(SHA-256, 310000 iter) → AES-256-GCM
    /// password: cihazın barmaq izi açarı (getDeviceKey())
    static EncryptResult encrypt(const QString& plaintext, const QString& password);

    /// Mətn aç: base64 blob → plaintext
    static DecryptResult decrypt(const QString& base64Blob, const QString& password);

private:
    /// PBKDF2-SHA-256 ilə 32 byte açar törət
    static QByteArray deriveKey(const QByteArray& password,
                                const QByteArray& salt,
                                int               iterations = 310000);
};

} // namespace Crypto
