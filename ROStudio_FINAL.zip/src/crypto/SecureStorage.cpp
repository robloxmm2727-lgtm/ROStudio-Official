// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — SecureStorage.cpp
//  localStorage → AES-256-GCM şifrəli JSON fayl
// ═══════════════════════════════════════════════════════════════════════════════
#include "SecureStorage.h"
#include "AesGcm.h"
#include "DeviceKey.h"

#include <QStandardPaths>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QDebug>

namespace Crypto {

// ─── Singleton ───────────────────────────────────────────────────────────────
SecureStorage& SecureStorage::instance()
{
    static SecureStorage inst;
    return inst;
}

SecureStorage::SecureStorage()
{
    // ~/.config/ROStudio/secure.dat
    const QString configDir = QStandardPaths::writableLocation(
        QStandardPaths::AppConfigLocation);
    QDir().mkpath(configDir);
    filePath_ = configDir + "/secure.dat";
}

// ─── Diskin oxunması ─────────────────────────────────────────────────────────
bool SecureStorage::loadFromDisk()
{
    if (loaded_) return true;
    loaded_ = true; // bir dəfə cəhd et

    QFile f(filePath_);
    if (!f.exists()) return true; // boş, bu normal

    if (!f.open(QIODevice::ReadOnly)) {
        qWarning() << "[SecureStorage] Fayl açılmadı:" << filePath_;
        return false;
    }
    const QString blob = QString::fromLatin1(f.readAll());
    f.close();

    if (blob.isEmpty()) return true;

    // Şifrəni aç
    const auto result = AesGcm::decrypt(blob, DeviceKey::get());
    if (!result.success) {
        qWarning() << "[SecureStorage] Şifrəaçma uğursuz:" << result.errorMsg;
        // Faylı silmə — köhnə format ola bilər
        return false;
    }

    // JSON parse
    const QJsonDocument doc = QJsonDocument::fromJson(result.plaintext.toUtf8());
    if (doc.isObject()) {
        cache_ = doc.object();
    }
    return true;
}

// ─── Diskə yazma ─────────────────────────────────────────────────────────────
bool SecureStorage::flushToDisk()
{
    const QString json = QString::fromUtf8(
        QJsonDocument(cache_).toJson(QJsonDocument::Compact));

    const auto result = AesGcm::encrypt(json, DeviceKey::get());
    if (!result.success) {
        qWarning() << "[SecureStorage] Şifrələmə uğursuz:" << result.errorMsg;
        return false;
    }

    QFile f(filePath_);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        qWarning() << "[SecureStorage] Fayla yazılmadı:" << filePath_;
        return false;
    }
    f.write(result.base64Blob.toLatin1());
    f.close();
    return true;
}

// ─── Public API ──────────────────────────────────────────────────────────────
bool SecureStorage::store(const QString& key, const QString& value)
{
    loadFromDisk();
    cache_[key] = value;
    return flushToDisk();
}

std::optional<QString> SecureStorage::load(const QString& key)
{
    loadFromDisk();
    if (!cache_.contains(key)) return std::nullopt;
    return cache_[key].toString();
}

void SecureStorage::remove(const QString& key)
{
    loadFromDisk();
    cache_.remove(key);
    flushToDisk();
}

void SecureStorage::clear()
{
    cache_ = QJsonObject();
    QFile::remove(filePath_);
    loaded_ = false;
}

QString SecureStorage::filePath() const
{
    return filePath_;
}

} // namespace Crypto
