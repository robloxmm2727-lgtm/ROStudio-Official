// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — DeviceKey.cpp
// ═══════════════════════════════════════════════════════════════════════════════
#include "DeviceKey.h"
#include <QSysInfo>
#include <QGuiApplication>
#include <QScreen>
#include <QLocale>
#include <QThread>
#include <QHostInfo>

namespace Crypto {

QString DeviceKey::cached_;

QString DeviceKey::get()
{
    if (!cached_.isEmpty()) return cached_;

    // JS equivalenti:
    //   navigator.userAgent → OS + kernel versiyası
    //   screen.width, screen.height
    //   navigator.language
    //   navigator.hardwareConcurrency
    const QString osType    = QSysInfo::productType();
    const QString osVersion = QSysInfo::productVersion();
    const QString kernel    = QSysInfo::kernelVersion();
    const QString arch      = QSysInfo::currentCpuArchitecture();
    const QString hostname  = QHostInfo::localHostName();

    int screenW = 0, screenH = 0;
    if (QGuiApplication::primaryScreen()) {
        const QSize sz = QGuiApplication::primaryScreen()->size();
        screenW = sz.width();
        screenH = sz.height();
    }

    const QString lang = QLocale::system().name();          // "en_US", "az_AZ" ...
    const int     cpus = QThread::idealThreadCount();

    // Format: "userAgent|width|height|lang|cpus|ROStudio-CyberWeld-v5"
    // userAgent ≈ "osType osVersion kernel arch hostname"
    const QString userAgent = QString("%1 %2 (%3; %4) %5")
        .arg(osType, osVersion, kernel, arch, hostname);

    cached_ = QString("%1|%2|%3|%4|%5|ROStudio-CyberWeld-v5")
        .arg(userAgent)
        .arg(screenW).arg(screenH)
        .arg(lang)
        .arg(cpus);

    return cached_;
}

} // namespace Crypto
