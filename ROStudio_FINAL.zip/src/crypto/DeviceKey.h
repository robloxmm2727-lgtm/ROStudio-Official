#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — DeviceKey.h / DeviceKey.cpp
//  JS-dəki getDeviceKey() funksiyasının C++ qarşılığı.
//  Cihaz barmaq izi: OS + hostname + screen + lang + CPU count
// ═══════════════════════════════════════════════════════════════════════════════
#include <QString>

namespace Crypto {

class DeviceKey {
public:
    /// JS-dəki: [userAgent, screen.width, screen.height, language, hardwareConcurrency]
    ///           .join('|') + '|ROStudio-CyberWeld-v5'
    /// C++-da: OS bilgisi + ekran + dil + CPU + hostname birləşdirilir
    static QString get();

private:
    static QString cached_; // lazım olduqda bir dəfə hesabla
};

} // namespace Crypto
