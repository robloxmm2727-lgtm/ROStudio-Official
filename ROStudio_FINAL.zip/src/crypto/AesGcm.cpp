// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — AesGcm.cpp
//  OpenSSL ilə AES-256-GCM (JS WebCrypto AES-GCM-ə tam ekvivalent)
// ═══════════════════════════════════════════════════════════════════════════════

#include "AesGcm.h"
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <QRandomGenerator>
#include <QDebug>

namespace Crypto {

// ─── PBKDF2-SHA-256 açar törətmə ─────────────────────────────────────────────
QByteArray AesGcm::deriveKey(const QByteArray& password,
                              const QByteArray& salt,
                              int               iterations)
{
    QByteArray key(32, 0); // 256-bit
    int ok = PKCS5_PBKDF2_HMAC(
        password.constData(),  password.size(),
        reinterpret_cast<const unsigned char*>(salt.constData()), salt.size(),
        iterations,
        EVP_sha256(),
        key.size(),
        reinterpret_cast<unsigned char*>(key.data())
    );
    if (!ok) {
        qWarning() << "[Crypto] PBKDF2 uğursuz oldu";
        return {};
    }
    return key;
}

// ─── Şifrələmə ───────────────────────────────────────────────────────────────
// Blob formatı: salt(16) || iv(12) || ciphertext || tag(16)
// JS WebCrypto ilə tam uyğun
EncryptResult AesGcm::encrypt(const QString& plaintext, const QString& password)
{
    EncryptResult result;

    // 1. Təsadüfi salt (16 byte) və IV (12 byte)
    QByteArray salt(16, 0);
    QByteArray iv(12, 0);
    if (RAND_bytes(reinterpret_cast<unsigned char*>(salt.data()), 16) != 1 ||
        RAND_bytes(reinterpret_cast<unsigned char*>(iv.data()),   12) != 1) {
        result.errorMsg = "Təsadüfi bayt generasiyası uğursuz oldu";
        return result;
    }

    // 2. Açar törət
    QByteArray passBytes = password.toUtf8();
    QByteArray key = deriveKey(passBytes, salt);
    if (key.isEmpty()) {
        result.errorMsg = "Açar törətmə uğursuz oldu";
        return result;
    }

    // 3. AES-256-GCM şifrələmə
    QByteArray ptBytes  = plaintext.toUtf8();
    QByteArray ctBytes(ptBytes.size() + 16, 0); // extra 16 tag üçün
    QByteArray tag(16, 0);

    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        result.errorMsg = "OpenSSL konteksti yaradılmadı";
        return result;
    }

    int len = 0, ctLen = 0;
    bool ok = true;

    ok = ok && EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), nullptr,
        reinterpret_cast<const unsigned char*>(key.constData()),
        reinterpret_cast<const unsigned char*>(iv.constData())) == 1;

    ok = ok && EVP_EncryptUpdate(ctx,
        reinterpret_cast<unsigned char*>(ctBytes.data()), &len,
        reinterpret_cast<const unsigned char*>(ptBytes.constData()), ptBytes.size()) == 1;
    ctLen = len;

    ok = ok && EVP_EncryptFinal_ex(ctx,
        reinterpret_cast<unsigned char*>(ctBytes.data()) + ctLen, &len) == 1;
    ctLen += len;

    ok = ok && EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16,
        reinterpret_cast<unsigned char*>(tag.data())) == 1;

    EVP_CIPHER_CTX_free(ctx);

    if (!ok) {
        result.errorMsg = "AES-GCM şifrələmə xətası";
        return result;
    }

    ctBytes.resize(ctLen);

    // 4. Blob: salt || iv || ciphertext || tag
    QByteArray blob;
    blob.reserve(16 + 12 + ctLen + 16);
    blob.append(salt);
    blob.append(iv);
    blob.append(ctBytes);
    blob.append(tag);

    result.base64Blob = QString::fromLatin1(blob.toBase64());
    result.success    = true;
    return result;
}

// ─── Şifrəaçma ───────────────────────────────────────────────────────────────
DecryptResult AesGcm::decrypt(const QString& base64Blob, const QString& password)
{
    DecryptResult result;

    QByteArray blob = QByteArray::fromBase64(base64Blob.toLatin1());
    if (blob.size() < 16 + 12 + 16) {
        result.errorMsg = "Blob çox qısa";
        return result;
    }

    QByteArray salt = blob.mid(0, 16);
    QByteArray iv   = blob.mid(16, 12);
    // ciphertext + tag; tag sonuncu 16 byte
    QByteArray ctAndTag = blob.mid(28);
    QByteArray tag  = ctAndTag.right(16);
    QByteArray ct   = ctAndTag.left(ctAndTag.size() - 16);

    QByteArray passBytes = password.toUtf8();
    QByteArray key = deriveKey(passBytes, salt);
    if (key.isEmpty()) {
        result.errorMsg = "Açar törətmə uğursuz oldu";
        return result;
    }

    QByteArray pt(ct.size() + 16, 0);
    int len = 0, ptLen = 0;
    bool ok = true;

    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        result.errorMsg = "OpenSSL konteksti yaradılmadı";
        return result;
    }

    ok = ok && EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), nullptr,
        reinterpret_cast<const unsigned char*>(key.constData()),
        reinterpret_cast<const unsigned char*>(iv.constData())) == 1;

    ok = ok && EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16,
        const_cast<char*>(tag.constData())) == 1;

    ok = ok && EVP_DecryptUpdate(ctx,
        reinterpret_cast<unsigned char*>(pt.data()), &len,
        reinterpret_cast<const unsigned char*>(ct.constData()), ct.size()) == 1;
    ptLen = len;

    int finalOk = EVP_DecryptFinal_ex(ctx,
        reinterpret_cast<unsigned char*>(pt.data()) + ptLen, &len);

    EVP_CIPHER_CTX_free(ctx);

    if (!ok || finalOk <= 0) {
        result.errorMsg = "GCM doğrulama xətası — yanlış açar?";
        return result;
    }

    ptLen += len;
    pt.resize(ptLen);
    result.plaintext = QString::fromUtf8(pt);
    result.success   = true;
    return result;
}

} // namespace Crypto
