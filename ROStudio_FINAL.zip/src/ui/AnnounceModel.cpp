#include "AnnounceModel.h"

AnnounceModel::AnnounceModel(QObject* parent) : QAbstractListModel(parent) {}

int AnnounceModel::rowCount(const QModelIndex&) const { return entries_.size(); }

QVariant AnnounceModel::data(const QModelIndex& idx, int role) const
{
    if (!idx.isValid() || idx.row() >= entries_.size()) return {};
    const auto& e = entries_[idx.row()];
    switch(role) {
    case TextRole:   return e.text;
    case TargetRole: return e.target;
    case TypeRole:   return e.type;
    case TimeRole:   return e.time;
    default:         return {};
    }
}

QHash<int,QByteArray> AnnounceModel::roleNames() const
{
    return {{TextRole,"text"},{TargetRole,"target"},
            {TypeRole,"type"},{TimeRole,"time"}};
}

void AnnounceModel::addHistoryEntry(const QString& text,
                                    const QString& target,
                                    const QString& type)
{
    const int row = entries_.size();
    beginInsertRows({}, row, row);
    entries_.prepend({text, target, type,
        QDateTime::currentDateTime().toString("HH:mm · dd/MM")});
    endInsertRows();
    emit entryAdded();
}

void AnnounceModel::reset()
{
    beginResetModel();
    entries_.clear();
    endResetModel();
}
