#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — TerminalModel.h
//  Terminal sətirləri üçün list modeli (QML ListView bağlantısı)
//  JS-dəki appendTermLine() funksiyasının C++ qarşılığı
// ═══════════════════════════════════════════════════════════════════════════════
#include <QAbstractListModel>
#include <QVector>
#include <QString>
#include <QDateTime>

struct TermLine {
    QString timestamp;   // "HH:mm:ss"
    QString level;       // "ok", "err", "warn", "sys", "info"
    QString tag;         // "[API]", "[SYS]" ...
    QString message;
};

class TerminalModel : public QAbstractListModel {
    Q_OBJECT
    Q_PROPERTY(int lineCount READ rowCount NOTIFY lineCountChanged)

public:
    enum Roles {
        TimestampRole = Qt::UserRole + 1,
        LevelRole,
        TagRole,
        MessageRole,
    };

    explicit TerminalModel(QObject* parent = nullptr);

    // QAbstractListModel virtual-ları
    int      rowCount(const QModelIndex& parent = {}) const override;
    QVariant data(const QModelIndex& index, int role) const override;
    QHash<int,QByteArray> roleNames() const override;

    // JS: appendTermLine(level, tag, msg)
    Q_INVOKABLE void appendLine(const QString& level,
                                const QString& tag,
                                const QString& msg);
    Q_INVOKABLE void clear();

signals:
    void lineCountChanged();
    void lineAppended(); // ListView avtoscroll üçün

private:
    static constexpr int MAX_LINES = 500;
    QVector<TermLine> lines_;
};
