// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — DashboardModel.cpp
// ═══════════════════════════════════════════════════════════════════════════════
#include "DashboardModel.h"

DashboardModel::DashboardModel(QObject* parent) : QObject(parent) {}

void DashboardModel::update(const Api::UniverseInfo& info, const QVector<int>& history)
{
    gameName_    = info.name;
    playerCount_ = info.playing;
    visitCount_  = info.visits;
    playerDelta_ = "online indi";
    chartData_   = history;

    emit dataChanged();
    emit chartUpdated();
}

void DashboardModel::setServerCount(int count)
{
    serverCount_ = count;
    emit dataChanged();
}

void DashboardModel::reset()
{
    gameName_    = "Yüklənir...";
    playerCount_ = 0;
    visitCount_  = 0;
    serverCount_ = 0;
    chartData_.clear();
    emit dataChanged();
    emit chartUpdated();
}

QString DashboardModel::visitCountStr() const
{
    int64_t n = visitCount_;
    if (n >= 1'000'000'000LL) return QString::number(n/1'000'000'000.0,'f',1)+"B";
    if (n >= 1'000'000LL)     return QString::number(n/1'000'000.0,'f',1)+"M";
    if (n >= 1'000LL)         return QString::number(n/1'000.0,'f',1)+"K";
    return QString::number(n);
}
