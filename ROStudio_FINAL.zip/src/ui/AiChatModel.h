#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  AiChatModel.h + AiChatModel.cpp + AnnounceModel.h + AnnounceModel.cpp
// ═══════════════════════════════════════════════════════════════════════════════
#include <QAbstractListModel>
#include <QVector>
#include <QString>
#include <QDateTime>

// ─── Chat mesajı ──────────────────────────────────────────────────────────────
struct ChatMessage {
    QString role;    // "user" ya "assistant"
    QString text;
    QString time;
};

class AiChatModel : public QAbstractListModel {
    Q_OBJECT
    Q_PROPERTY(bool thinking READ thinking NOTIFY thinkingChanged)

public:
    enum Roles { RoleRole = Qt::UserRole+1, TextRole, TimeRole };
    explicit AiChatModel(QObject* parent = nullptr);

    int      rowCount(const QModelIndex& p = {}) const override;
    QVariant data(const QModelIndex& idx, int role) const override;
    QHash<int,QByteArray> roleNames() const override;

    bool thinking() const { return thinking_; }

    Q_INVOKABLE void addUserMessage(const QString& text);
    Q_INVOKABLE void addAssistantMessage(const QString& text);
    void setThinking(bool v);
    void reset();

signals:
    void thinkingChanged();
    void messageAdded();

private:
    QVector<ChatMessage> messages_;
    bool                 thinking_ = false;
};
