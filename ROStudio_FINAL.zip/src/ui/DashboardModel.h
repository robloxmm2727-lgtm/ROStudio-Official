#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — DashboardModel.h
//  Dashboard panel üçün veri modeli (QML property binding-ləri)
// ═══════════════════════════════════════════════════════════════════════════════
#include <QObject>
#include <QString>
#include <QVector>
#include "../api/ApiResponse.h"

class DashboardModel : public QObject {
    Q_OBJECT

    Q_PROPERTY(QString gameName    READ gameName    NOTIFY dataChanged)
    Q_PROPERTY(int     playerCount READ playerCount NOTIFY dataChanged)
    Q_PROPERTY(QString visitCount  READ visitCountStr NOTIFY dataChanged)
    Q_PROPERTY(int     serverCount READ serverCount NOTIFY dataChanged)
    Q_PROPERTY(QString playerDelta READ playerDelta NOTIFY dataChanged)
    Q_PROPERTY(QVector<int> chartData READ chartData NOTIFY chartUpdated)

public:
    explicit DashboardModel(QObject* parent = nullptr);

    QString gameName()     const { return gameName_; }
    int     playerCount()  const { return playerCount_; }
    int64_t visitCount()   const { return visitCount_; }
    QString visitCountStr() const;
    int     serverCount()  const { return serverCount_; }
    QString playerDelta()  const { return playerDelta_; }
    QVector<int> chartData() const { return chartData_; }

    void update(const Api::UniverseInfo& info, const QVector<int>& history);
    void setServerCount(int count);
    void reset();

signals:
    void dataChanged();
    void chartUpdated();

private:
    QString      gameName_    = "Yüklənir...";
    int          playerCount_ = 0;
    int64_t      visitCount_  = 0;
    int          serverCount_ = 0;
    QString      playerDelta_ = "online indi";
    QVector<int> chartData_;
};
