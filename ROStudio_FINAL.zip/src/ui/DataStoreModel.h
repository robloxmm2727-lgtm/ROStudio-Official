#pragma once
// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — DataStoreModel.h
// ═══════════════════════════════════════════════════════════════════════════════
#include <QAbstractListModel>
#include <QJsonValue>
#include <QString>

struct DsEntry {
    QString    key;
    QString    valueStr;
    QString    type; // "number", "string", "table"
};

class DataStoreModel : public QAbstractListModel {
    Q_OBJECT
    Q_PROPERTY(QString storeName READ storeName NOTIFY storeNameChanged)
    Q_PROPERTY(bool    loading   READ loading   NOTIFY loadingChanged)
    Q_PROPERTY(QString errorMsg  READ errorMsg  NOTIFY errorChanged)

public:
    enum Roles {
        KeyRole = Qt::UserRole + 1,
        ValueRole,
        TypeRole,
    };
    explicit DataStoreModel(QObject* parent = nullptr);

    int      rowCount(const QModelIndex& p = {}) const override;
    QVariant data(const QModelIndex& idx, int role) const override;
    QHash<int,QByteArray> roleNames() const override;

    QString storeName() const { return storeName_; }
    bool    loading()   const { return loading_; }
    QString errorMsg()  const { return errorMsg_; }

    void setKeys(const QString& store, const QStringList& keys);
    void setEntryValue(const QString& key, const QJsonValue& val);
    void reset();

signals:
    void storeNameChanged();
    void loadingChanged();
    void errorChanged();

private:
    QVector<DsEntry> entries_;
    QString          storeName_ = "PlayerData";
    bool             loading_   = false;
    QString          errorMsg_;
};
