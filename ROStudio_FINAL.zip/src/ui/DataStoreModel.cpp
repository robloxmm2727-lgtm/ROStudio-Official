// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — DataStoreModel.cpp
// ═══════════════════════════════════════════════════════════════════════════════
#include "DataStoreModel.h"
#include <QJsonDocument>
#include <QJsonObject>

DataStoreModel::DataStoreModel(QObject* parent) : QAbstractListModel(parent) {}

int DataStoreModel::rowCount(const QModelIndex&) const { return entries_.size(); }

QVariant DataStoreModel::data(const QModelIndex& idx, int role) const
{
    if (!idx.isValid() || idx.row() >= entries_.size()) return {};
    const auto& e = entries_[idx.row()];
    switch(role) {
    case KeyRole:   return e.key;
    case ValueRole: return e.valueStr;
    case TypeRole:  return e.type;
    default:        return {};
    }
}

QHash<int,QByteArray> DataStoreModel::roleNames() const
{
    return {{KeyRole,"key"},{ValueRole,"value"},{TypeRole,"type"}};
}

void DataStoreModel::setKeys(const QString& store, const QStringList& keys)
{
    beginResetModel();
    storeName_ = store;
    entries_.clear();
    for (const auto& k : keys)
        entries_.append({k, "...", "?"});
    loading_ = false;
    errorMsg_.clear();
    endResetModel();
    emit storeNameChanged();
    emit loadingChanged();
    emit errorChanged();
}

void DataStoreModel::setEntryValue(const QString& key, const QJsonValue& val)
{
    for (int i = 0; i < entries_.size(); ++i) {
        if (entries_[i].key == key) {
            QString type, str;
            if (val.isDouble())      { type="number"; str=QString::number(val.toDouble()); }
            else if (val.isString()) { type="string"; str=val.toString(); }
            else if (val.isObject()  || val.isArray())
                { type="table"; str=QJsonDocument(val.toObject()).toJson(QJsonDocument::Compact); }
            else if (val.isBool())   { type="boolean"; str=val.toBool()?"true":"false"; }
            entries_[i].valueStr = str;
            entries_[i].type     = type;
            const QModelIndex mi = index(i);
            emit dataChanged(mi, mi, {ValueRole, TypeRole});
            return;
        }
    }
}

void DataStoreModel::reset()
{
    beginResetModel();
    entries_.clear();
    endResetModel();
}
