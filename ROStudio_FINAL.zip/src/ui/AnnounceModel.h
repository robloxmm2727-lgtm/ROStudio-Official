#pragma once
#include <QAbstractListModel>
#include <QVector>
#include <QString>
#include <QDateTime>

struct AnnounceEntry {
    QString text;
    QString target;   // "all", "vip", "mod"
    QString type;     // "now", "scheduled"
    QString time;
};

class AnnounceModel : public QAbstractListModel {
    Q_OBJECT
public:
    enum Roles { TextRole=Qt::UserRole+1, TargetRole, TypeRole, TimeRole };
    explicit AnnounceModel(QObject* parent = nullptr);

    int      rowCount(const QModelIndex& p = {}) const override;
    QVariant data(const QModelIndex& i, int role) const override;
    QHash<int,QByteArray> roleNames() const override;

    Q_INVOKABLE void addHistoryEntry(const QString& text,
                                     const QString& target,
                                     const QString& type);
    void reset();

signals:
    void entryAdded();

private:
    QVector<AnnounceEntry> entries_;
};
