// AiChatModel.cpp
#include "AiChatModel.h"

AiChatModel::AiChatModel(QObject* parent) : QAbstractListModel(parent) {}

int AiChatModel::rowCount(const QModelIndex&) const { return messages_.size(); }

QVariant AiChatModel::data(const QModelIndex& idx, int role) const
{
    if (!idx.isValid() || idx.row() >= messages_.size()) return {};
    const auto& m = messages_[idx.row()];
    switch(role) {
    case RoleRole: return m.role;
    case TextRole: return m.text;
    case TimeRole: return m.time;
    default:       return {};
    }
}

QHash<int,QByteArray> AiChatModel::roleNames() const
{
    return {{RoleRole,"role"},{TextRole,"text"},{TimeRole,"time"}};
}

void AiChatModel::addUserMessage(const QString& text)
{
    const int row = messages_.size();
    beginInsertRows({}, row, row);
    messages_.append({"user", text,
        QDateTime::currentDateTime().toString("HH:mm")});
    endInsertRows();
    emit messageAdded();
}

void AiChatModel::addAssistantMessage(const QString& text)
{
    const int row = messages_.size();
    beginInsertRows({}, row, row);
    messages_.append({"assistant", text,
        QDateTime::currentDateTime().toString("HH:mm")});
    endInsertRows();
    emit messageAdded();
}

void AiChatModel::setThinking(bool v)
{
    if (thinking_ == v) return;
    thinking_ = v;
    emit thinkingChanged();
}

void AiChatModel::reset()
{
    beginResetModel();
    messages_.clear();
    thinking_ = false;
    endResetModel();
    emit thinkingChanged();
}
