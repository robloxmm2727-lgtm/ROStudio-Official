// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — TerminalModel.cpp
// ═══════════════════════════════════════════════════════════════════════════════
#include "TerminalModel.h"

TerminalModel::TerminalModel(QObject* parent) : QAbstractListModel(parent) {}

int TerminalModel::rowCount(const QModelIndex& /*parent*/) const
{
    return lines_.size();
}

QVariant TerminalModel::data(const QModelIndex& index, int role) const
{
    if (!index.isValid() || index.row() >= lines_.size()) return {};
    const auto& l = lines_[index.row()];
    switch (role) {
    case TimestampRole: return l.timestamp;
    case LevelRole:     return l.level;
    case TagRole:       return l.tag;
    case MessageRole:   return l.message;
    default:            return {};
    }
}

QHash<int,QByteArray> TerminalModel::roleNames() const
{
    return {
        {TimestampRole, "timestamp"},
        {LevelRole,     "level"},
        {TagRole,       "tag"},
        {MessageRole,   "message"},
    };
}

void TerminalModel::appendLine(const QString& level,
                                const QString& tag,
                                const QString& msg)
{
    // Overflow qoruması (JS-də yox idi, amma C++-da lazımdır)
    if (lines_.size() >= MAX_LINES) {
        beginRemoveRows({}, 0, 0);
        lines_.removeFirst();
        endRemoveRows();
    }

    const int row = lines_.size();
    beginInsertRows({}, row, row);
    lines_.append({
        QDateTime::currentDateTime().toString("HH:mm:ss"),
        level, tag, msg
    });
    endInsertRows();

    emit lineCountChanged();
    emit lineAppended();
}

void TerminalModel::clear()
{
    beginResetModel();
    lines_.clear();
    endResetModel();
    emit lineCountChanged();
}
