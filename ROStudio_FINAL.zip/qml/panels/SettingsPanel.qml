// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — SettingsPanel.qml
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

ColumnLayout {
    spacing: 12

    // ─── API Konfiqurasiya ───────────────────────────────────────────────────
    Rectangle {
        Layout.fillWidth: true; radius: 14
        color: "#131620"; border.color: "rgba(255,255,255,0.07)"; border.width: 1
        implicitHeight: apiCol.implicitHeight + 28

        ColumnLayout {
            id: apiCol
            anchors { fill: parent; margins: 14 }
            spacing: 14

            Row { spacing: 8
                Rectangle { width: 3; height: 12; radius: 1; color: "#7c6bff"; anchors.verticalCenter: parent.verticalCenter }
                Text { text: app.tr.t("set-api-sect").toUpperCase(); color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New"; letterSpacing: 1 }
            }

            // Cari API açarı (maskəli)
            ColumnLayout { spacing: 4
                Text { text: app.tr.t("set-current-key"); color: "#5a5f6e"; font.pixelSize: 11 }
                Row { spacing: 8
                    Text { text: app.maskedApiKey; color: "#e8eaf2"; font.pixelSize: 13; font.family: "Courier New" }
                    Text {
                        text: "📋"; font.pixelSize: 13
                        MouseArea { anchors.fill: parent; onClicked: app.showToast("✓ Kopyalandı!", "success") }
                    }
                }
            }

            // Universe ID
            ColumnLayout { spacing: 4
                Text { text: app.tr.t("set-uid"); color: "#5a5f6e"; font.pixelSize: 11 }
                Text { text: app.universeId || "—"; color: "#e8eaf2"; font.pixelSize: 13; font.family: "Courier New" }
            }

            // API dəyiş düyməsi
            Rectangle {
                Layout.fillWidth: true; height: 44; radius: 9
                color: "rgba(124,107,255,0.1)"
                border.color: "rgba(124,107,255,0.25)"; border.width: 1
                Text { anchors.centerIn: parent; text: "🔑 " + app.tr.t("btn-change-api"); color: "#7c6bff"; font.pixelSize: 13; font.weight: Font.Bold }
                MouseArea { anchors.fill: parent; onClicked: apiModal.open() }
            }
        }
    }

    // ─── Üstünlüklər ────────────────────────────────────────────────────────
    Rectangle {
        Layout.fillWidth: true; radius: 14
        color: "#131620"; border.color: "rgba(255,255,255,0.07)"; border.width: 1
        implicitHeight: prefsCol.implicitHeight + 28

        ColumnLayout {
            id: prefsCol
            anchors { fill: parent; margins: 14 }
            spacing: 0

            Row { spacing: 8; Layout.bottomMargin: 14
                Rectangle { width: 3; height: 12; radius: 1; color: "#7c6bff"; anchors.verticalCenter: parent.verticalCenter }
                Text { text: app.tr.t("set-prefs").toUpperCase(); color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New"; letterSpacing: 1 }
            }

            // Dil sırası
            Rectangle {
                Layout.fillWidth: true; height: 54
                color: "transparent"
                border.color: "rgba(255,255,255,0.04)"; border.width: 1

                RowLayout {
                    anchors { fill: parent; leftMargin: 4; rightMargin: 4 }
                    Text { text: "🌐"; font.pixelSize: 18 }
                    ColumnLayout {
                        spacing: 2
                        Text { text: app.tr.t("set-lang"); color: "#e8eaf2"; font.pixelSize: 14 }
                        Text { text: app.tr.t("lang-name"); color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New" }
                    }
                    Item { Layout.fillWidth: true }
                    // Dil ComboBox
                    ComboBox {
                        model: ["EN", "AZ", "TR", "RU"]
                        property var codes: ["en","az","tr","ru"]
                        implicitWidth: 60; implicitHeight: 32
                        background: Rectangle { radius: 6; color: "#1a1d2b"; border.color: "rgba(255,255,255,0.07)"; border.width: 1 }
                        contentItem: Text { text: parent.currentText; color: "#e8eaf2"; font.pixelSize: 12; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
                        onCurrentIndexChanged: app.setLanguage(codes[currentIndex])
                        currentIndex: codes.indexOf(app.currentLang)
                    }
                }
            }

            // Qaranlıq rejim (həmişə aktiv)
            Rectangle {
                Layout.fillWidth: true; height: 54
                color: "transparent"
                border.color: "rgba(255,255,255,0.04)"; border.width: 1

                RowLayout {
                    anchors { fill: parent; leftMargin: 4; rightMargin: 4 }
                    Text { text: "🌙"; font.pixelSize: 18 }
                    ColumnLayout {
                        spacing: 2
                        Text { text: app.tr.t("set-dark"); color: "#e8eaf2"; font.pixelSize: 14 }
                        Text { text: app.tr.t("set-dark-sub"); color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New" }
                    }
                    Item { Layout.fillWidth: true }
                    // Həmişə aktiv toggle
                    Rectangle {
                        width: 44; height: 24; radius: 12; color: "#7c6bff"
                        Rectangle { x: 22; y: 2; width: 20; height: 20; radius: 10; color: "#fff" }
                    }
                }
            }
        }
    }

    // ─── Haqqında ────────────────────────────────────────────────────────────
    Rectangle {
        Layout.fillWidth: true; radius: 14
        color: "#131620"; border.color: "rgba(255,255,255,0.07)"; border.width: 1
        implicitHeight: aboutCol.implicitHeight + 28

        ColumnLayout {
            id: aboutCol
            anchors { fill: parent; margins: 14 }
            spacing: 8

            Row { spacing: 8
                Rectangle { width: 3; height: 12; radius: 1; color: "#7c6bff"; anchors.verticalCenter: parent.verticalCenter }
                Text { text: app.tr.t("set-about-sect").toUpperCase(); color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New"; letterSpacing: 1 }
            }

            ColumnLayout { spacing: 4
                Text { text: "ROStudio v5.0.0"; color: "#e8eaf2"; font.pixelSize: 14; font.weight: Font.Bold }
                Text { text: "by CyberWeld — Native C++ / Qt6 Edition"; color: "#5a5f6e"; font.pixelSize: 12; font.family: "Courier New" }
                Text { text: "AES-256-GCM · OpenSSL · QtNetwork · QML"; color: "#383d50"; font.pixelSize: 11; font.family: "Courier New" }
            }

            // Şifrələmə yolu
            Rectangle {
                Layout.fillWidth: true; height: 36; radius: 8
                color: "rgba(0,229,160,0.06)"
                border.color: "rgba(0,229,160,0.15)"; border.width: 1
                Text {
                    anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                    text: "🔒 " + Crypto.SecureStorage.filePath()
                    color: "rgba(0,229,160,0.7)"; font.pixelSize: 10; font.family: "Courier New"
                    elide: Text.ElideMiddle
                    width: parent.width - 24
                }
            }
        }
    }

    // ─── Çıxış düyməsi ──────────────────────────────────────────────────────
    Rectangle {
        Layout.fillWidth: true; height: 48; radius: 12
        color: "rgba(255,95,95,0.08)"
        border.color: "rgba(255,95,95,0.25)"; border.width: 1
        Text { anchors.centerIn: parent; text: app.tr.t("btn-logout"); color: "#ff5f5f"; font.pixelSize: 14; font.weight: Font.Bold }
        MouseArea { anchors.fill: parent; onClicked: app.doLogout() }
    }

    Item { height: 14 }
}
