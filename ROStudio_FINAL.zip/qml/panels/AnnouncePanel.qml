// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — AnnouncePanel.qml
//  HTML #panel-announce-ın QML qarşılığı
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

ColumnLayout {
    spacing: 12

    // ─── Hədəf seçimi (All / VIP / Mods) ───────────────────────────────────
    property string selectedTarget: "all"

    Rectangle {
        Layout.fillWidth: true; radius: 14
        color: "#131620"; border.color: "rgba(255,255,255,0.07)"; border.width: 1
        implicitHeight: annCardCol.implicitHeight + 28

        ColumnLayout {
            id: annCardCol
            anchors { fill: parent; margins: 14 }
            spacing: 14

            // Section label
            Row { spacing: 8
                Rectangle { width: 3; height: 12; radius: 1; color: "#7c6bff"; anchors.verticalCenter: parent.verticalCenter }
                Text { text: app.tr.t("sect-new-msg").toUpperCase(); color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New"; letterSpacing: 1 }
            }

            // Hədəf düymələri
            Row {
                spacing: 8
                Repeater {
                    model: [
                        { key: "mtype-all", val: "all" },
                        { key: "mtype-vip", val: "vip" },
                        { key: "mtype-mod", val: "mod" },
                    ]
                    delegate: Rectangle {
                        height: 34; radius: 8
                        implicitWidth: mTypeText.implicitWidth + 20
                        color: selectedTarget === modelData.val ? "rgba(124,107,255,0.15)" : "#1a1d2b"
                        border.color: selectedTarget === modelData.val ? "rgba(124,107,255,0.5)" : "rgba(255,255,255,0.07)"
                        border.width: 1
                        Text {
                            id: mTypeText; anchors.centerIn: parent
                            text: app.tr.t(modelData.key)
                            color: selectedTarget === modelData.val ? "#7c6bff" : "#5a5f6e"
                            font.pixelSize: 12
                        }
                        MouseArea { anchors.fill: parent; onClicked: selectedTarget = modelData.val }
                    }
                }
            }

            // Mesaj sahəsi
            Rectangle {
                Layout.fillWidth: true; height: 90; radius: 9
                color: "#1a1d2b"
                border.color: msgArea.activeFocus ? "rgba(124,107,255,0.45)" : "rgba(255,255,255,0.07)"
                border.width: 1

                TextArea {
                    id: msgArea
                    anchors { fill: parent; margins: 12 }
                    background: Item {}
                    placeholderText: "Elan mətnini yazın..."
                    placeholderTextColor: "#383d50"
                    color: "#e8eaf2"; font.pixelSize: 14
                    wrapMode: TextArea.Wrap
                }
            }

            // Göndər düyməsi
            Rectangle {
                Layout.fillWidth: true; height: 46; radius: 10
                color: "#7c6bff"
                layer.enabled: true
                Text {
                    anchors.centerIn: parent
                    text: "📢 " + app.tr.t("btn-send-announce")
                    color: "#fff"; font.pixelSize: 14; font.weight: Font.Bold
                }
                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        if (msgArea.text.trim().length > 0) {
                            app.sendAnnouncement(msgArea.text.trim(), selectedTarget, "now")
                            msgArea.text = ""
                        }
                    }
                }
            }
        }
    }

    // ─── Tarixçə ────────────────────────────────────────────────────────────
    Row { spacing: 8
        Rectangle { width: 3; height: 12; radius: 1; color: "#7c6bff"; anchors.verticalCenter: parent.verticalCenter }
        Text { text: app.tr.t("sect-history").toUpperCase(); color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New"; letterSpacing: 1 }
    }

    Repeater {
        model: app.announce
        delegate: Rectangle {
            Layout.fillWidth: true; width: parent.width
            implicitHeight: ahCol.implicitHeight + 20
            radius: 10; color: "#131620"
            border.color: "rgba(255,255,255,0.05)"; border.width: 1

            ColumnLayout {
                id: ahCol
                anchors { fill: parent; margins: 12 }
                spacing: 6

                RowLayout {
                    Text { text: model.time; color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New" }
                    Item { Layout.fillWidth: true }
                    Rectangle {
                        height: 18; radius: 4
                        implicitWidth: typeTag.implicitWidth + 12
                        color: model.type === "now" ? "rgba(0,229,160,0.1)" : "rgba(255,181,71,0.1)"
                        Text {
                            id: typeTag; anchors.centerIn: parent
                            text: model.type === "now" ? "GÖNDƏRILDI" : "PLANLANIB"
                            color: model.type === "now" ? "#00e5a0" : "#ffb547"
                            font.pixelSize: 9; font.family: "Courier New"
                        }
                    }
                }
                Text { text: model.text; color: "#e8eaf2"; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            }
        }
    }

    Item { height: 14 }
}
