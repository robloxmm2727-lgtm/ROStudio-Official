// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — DataStorePanel.qml
//  HTML #panel-datastore-ın tam QML qarşılığı
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

ColumnLayout {
    spacing: 10

    // ─── Axtarış sıra (store adı + Load düyməsi) ────────────────────────────
    RowLayout {
        Layout.fillWidth: true; spacing: 8

        Rectangle {
            Layout.fillWidth: true; height: 44; radius: 9
            color: "#1a1d2b"; border.color: "rgba(255,255,255,0.07)"; border.width: 1

            RowLayout {
                anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                Text { text: "🗄"; font.pixelSize: 14 }
                TextField {
                    id: dsNameInput
                    Layout.fillWidth: true
                    background: Item {}
                    text: "PlayerData"
                    color: "#e8eaf2"; font.pixelSize: 13
                    placeholderTextColor: "#383d50"
                    onAccepted: app.loadDataStore(text.trim())
                }
            }
        }

        Rectangle {
            width: 64; height: 44; radius: 9
            color: "#7c6bff"
            Text { anchors.centerIn: parent; text: "Load"; color: "#fff"; font.pixelSize: 13; font.weight: Font.Bold }
            MouseArea { anchors.fill: parent; onClicked: app.loadDataStore(dsNameInput.text.trim()) }
        }
    }

    // ─── Axtarış filtri ────────────────────────────────────────────────────
    Rectangle {
        Layout.fillWidth: true; height: 38; radius: 9
        color: "#1a1d2b"; border.color: "rgba(255,255,255,0.07)"; border.width: 1

        RowLayout {
            anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
            Text { text: "🔍"; font.pixelSize: 13 }
            TextField {
                id: dsFilter
                Layout.fillWidth: true
                background: Item {}
                placeholderText: "Açar axtar..."
                color: "#e8eaf2"; font.pixelSize: 12
                placeholderTextColor: "#383d50"
            }
        }
    }

    // ─── DataStore siyahısı ─────────────────────────────────────────────────
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: Math.min(dsList.contentHeight + 2, 400)
        radius: 14; color: "#131620"
        border.color: "rgba(255,255,255,0.07)"; border.width: 1
        clip: true

        // Boş vəziyyət
        Text {
            anchors.centerIn: parent
            visible: app.dataStore.rowCount === 0
            text: "DataStore boşdur\n\nStore adı daxil edib Load basın"
            color: "#5a5f6e"; font.pixelSize: 12; font.family: "Courier New"
            horizontalAlignment: Text.AlignHCenter
        }

        ListView {
            id: dsList
            anchors.fill: parent
            model: app.dataStore
            clip: true

            delegate: Rectangle {
                width: dsList.width
                height: 52
                color: mouseArea.pressed ? "#1a1d2b" : "transparent"
                border.color: "rgba(255,255,255,0.04)"; border.width: 1

                // Filtrlənmiş görünüş
                visible: dsFilter.text.length === 0 ||
                         model.key.toLowerCase().includes(dsFilter.text.toLowerCase())
                height: visible ? 52 : 0

                RowLayout {
                    anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                    spacing: 12

                    // Tip badge
                    Rectangle {
                        width: 40; height: 20; radius: 4
                        color: {
                            switch(model.type) {
                            case "number":  return "rgba(124,107,255,0.15)"
                            case "string":  return "rgba(0,229,160,0.12)"
                            case "table":   return "rgba(255,181,71,0.12)"
                            default:        return "rgba(255,255,255,0.05)"
                            }
                        }
                        Text {
                            anchors.centerIn: parent
                            text: model.type === "?" ? "..." : model.type.substring(0,3).toUpperCase()
                            color: {
                                switch(model.type) {
                                case "number":  return "#7c6bff"
                                case "string":  return "#00e5a0"
                                case "table":   return "#ffb547"
                                default:        return "#5a5f6e"
                                }
                            }
                            font.pixelSize: 9; font.family: "Courier New"
                        }
                    }

                    // Açar + dəyər
                    ColumnLayout {
                        Layout.fillWidth: true; spacing: 2
                        Text {
                            text: model.key
                            color: "#e8eaf2"; font.pixelSize: 13; font.weight: Font.Medium
                            elide: Text.ElideRight
                            Layout.fillWidth: true
                        }
                        Text {
                            text: model.value || "..."
                            color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New"
                            elide: Text.ElideRight
                            Layout.fillWidth: true
                        }
                    }

                    // Düzəliş düyməsi
                    Text { text: "✏"; font.pixelSize: 14; color: "#5a5f6e" }
                }

                MouseArea {
                    id: mouseArea
                    anchors.fill: parent
                    onClicked: {
                        // Gələcəkdə dəyər redaktoru açılacaq
                    }
                }
            }

            ScrollBar.vertical: ScrollBar {
                width: 3
                contentItem: Rectangle { radius: 1.5; color: "#383d50" }
            }
        }
    }

    Item { height: 14 }
}
