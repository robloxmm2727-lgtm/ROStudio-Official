// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — DashboardPanel.qml
//  HTML #panel-dashboard-ın tam QML qarşılığı
//  StatCard-lar, GameCard-lar, BarChart
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

ColumnLayout {
    spacing: 12

    // ─── 2x2 Stat grid ──────────────────────────────────────────────────────
    Grid {
        Layout.fillWidth: true
        columns: 2
        columnSpacing: 10; rowSpacing: 10

        // Aktiv Oyunçular (c-green)
        StatCard {
            width: (parent.width - 10) / 2
            icon: "👥"
            label: app.tr.t("stat-players")
            value: app.dashboard.playerCount.toLocaleString()
            delta: app.dashboard.playerDelta
            deltaUp: true
            accentColor: "#00e5a0"
        }

        // Robux (c-amber)
        StatCard {
            width: (parent.width - 10) / 2
            icon: "💰"
            label: app.tr.t("stat-robux")
            value: "N/A"
            delta: "+0%"
            deltaUp: true
            accentColor: "#ffb547"
        }

        // Ümumi Ziyarət (c-purple)
        StatCard {
            width: (parent.width - 10) / 2
            icon: "🚀"
            label: app.tr.t("stat-visits")
            value: app.dashboard.visitCount
            delta: "all time"
            deltaUp: false
            accentColor: "#7c6bff"
        }

        // Xətalar (c-red)
        StatCard {
            width: (parent.width - 10) / 2
            icon: "⚠"
            label: app.tr.t("stat-errors")
            value: "0"
            delta: app.tr.t("stat-errors-sub")
            deltaUp: false
            accentColor: "#ff5f5f"
        }
    }

    // ─── Section label: Active Games ────────────────────────────────────────
    SectionLabel { text: app.tr.t("sect-active-games") }

    // ─── Əsas oyun kartı ────────────────────────────────────────────────────
    GameCard {
        Layout.fillWidth: true
        gameName: app.dashboard.gameName
        players: app.dashboard.playerCount
        servers: app.dashboard.serverCount
        visits: app.dashboard.visitCount
        isLive: true
    }

    // ─── Section label: Weekly ──────────────────────────────────────────────
    SectionLabel { text: app.tr.t("sect-weekly") }

    // ─── Ziyarət qrafiki ────────────────────────────────────────────────────
    BarChart {
        Layout.fillWidth: true
        chartData: app.dashboard.chartData
        title: app.tr.t("chart-visits-title")
    }

    Item { height: 14 }
}

// ─── Yardımçı komponentlər (bu fayl daxilindədir) ─────────────────────────

component SectionLabel: Item {
    Layout.fillWidth: true
    implicitHeight: 20
    property string text: ""

    Row {
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width
        spacing: 8
        Text {
            text: parent.parent.text
            color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New"
            letterSpacing: 1; font.capitalization: Font.AllUppercase
        }
        Rectangle {
            width: parent.parent.width - 120; height: 1
            color: "rgba(255,255,255,0.07)"
            anchors.verticalCenter: parent.verticalCenter
        }
    }
}
