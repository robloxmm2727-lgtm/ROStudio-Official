// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — TeamPanel.qml
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

ColumnLayout {
    spacing: 12

    Rectangle {
        Layout.fillWidth: true; radius: 14
        color: "#131620"; border.color: "rgba(255,255,255,0.07)"; border.width: 1
        implicitHeight: teamCol.implicitHeight + 28

        ColumnLayout {
            id: teamCol
            anchors { fill: parent; margins: 14 }
            spacing: 0

            Row { spacing: 8; Layout.bottomMargin: 14
                Rectangle { width: 3; height: 12; radius: 1; color: "#7c6bff"; anchors.verticalCenter: parent.verticalCenter }
                Text { text: app.tr.t("sect-team").toUpperCase(); color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New"; letterSpacing: 1 }
            }

            Repeater {
                model: [
                    { name: "CyberWeld",   role: "Owner",    online: true  },
                    { name: "Developer_2", role: "Scripter", online: false },
                    { name: "Builder_X",   role: "Builder",  online: false },
                ]
                delegate: Rectangle {
                    Layout.fillWidth: true; width: parent.width
                    height: 54; color: "transparent"
                    border.color: "rgba(255,255,255,0.04)"; border.width: 1

                    RowLayout {
                        anchors { fill: parent; leftMargin: 4; rightMargin: 4 }
                        spacing: 10
                        Text { text: modelData.online ? "🟢" : "⚫"; font.pixelSize: 14 }
                        ColumnLayout {
                            spacing: 2
                            Text { text: modelData.name; color: "#e8eaf2"; font.pixelSize: 14; font.weight: Font.Medium }
                            Text { text: modelData.role; color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New" }
                        }
                        Item { Layout.fillWidth: true }
                    }
                }
            }
        }
    }

    // Dəvət düyməsi
    Rectangle {
        Layout.fillWidth: true; height: 46; radius: 10
        color: "rgba(124,107,255,0.1)"
        border.color: "rgba(124,107,255,0.25)"; border.width: 1
        Text { anchors.centerIn: parent; text: app.tr.t("btn-invite"); color: "#7c6bff"; font.pixelSize: 13; font.weight: Font.Bold }
        MouseArea { anchors.fill: parent; onClicked: {} }
    }

    Item { height: 14 }
}
