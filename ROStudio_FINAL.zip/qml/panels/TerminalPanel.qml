// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — TerminalPanel.qml
//  HTML #panel-terminal-ın tam QML qarşılığı
//  ListView ilə sonsuz log, input sıra
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

ColumnLayout {
    spacing: 12
    implicitHeight: termBox.implicitHeight

    // ─── Terminal qutusu ──────────────────────────────────────────────────────
    Rectangle {
        id: termBox
        Layout.fillWidth: true
        implicitHeight: 340
        radius: 14
        color: "#060810"
        border.color: "rgba(255,255,255,0.07)"; border.width: 1
        clip: true

        ColumnLayout {
            anchors.fill: parent
            spacing: 0

            // Başlıq sıra (macOS tərzi rəngli nöqtələr)
            Rectangle {
                Layout.fillWidth: true
                height: 38
                color: "#0c0e18"
                border.color: "rgba(255,255,255,0.07)"; border.width: 1

                RowLayout {
                    anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter }
                    spacing: 6
                    Rectangle { width: 9; height: 9; radius: 4.5; color: "#ff5f57" }
                    Rectangle { width: 9; height: 9; radius: 4.5; color: "#ffbd2e" }
                    Rectangle { width: 9; height: 9; radius: 4.5; color: "#28c840" }
                }

                Text {
                    anchors.centerIn: parent
                    text: "ROStudio Terminal v0.1"
                    color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New"
                }

                // CLEAR düyməsi
                Rectangle {
                    anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                    height: 22; radius: 5
                    color: "rgba(255,255,255,0.04)"
                    border.color: "rgba(255,255,255,0.07)"; border.width: 1
                    implicitWidth: clearText.implicitWidth + 16
                    Text {
                        id: clearText
                        anchors.centerIn: parent
                        text: app.tr.t("term-clear")
                        color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New"
                    }
                    MouseArea { anchors.fill: parent; onClicked: app.clearTerminal() }
                }
            }

            // ─── Log sırası (ListView) ─────────────────────────────────────
            ListView {
                id: termList
                Layout.fillWidth: true
                Layout.fillHeight: true
                model: app.terminal
                clip: true
                bottomMargin: 6; topMargin: 6
                leftMargin: 14; rightMargin: 14

                // Yeni sətir əlavə olunanda avtomatik aşağı sürüş
                Connections {
                    target: app.terminal
                    function onLineAppended() {
                        termList.positionViewAtEnd()
                    }
                }

                delegate: Row {
                    width: termList.width - 28
                    spacing: 6
                    padding: 1

                    // Timestamp
                    Text {
                        text: model.timestamp
                        color: "#383d50"; font.pixelSize: 11
                        font.family: "Courier New"
                        width: 60; elide: Text.ElideRight
                    }

                    // Tag (rənglənmiş)
                    Text {
                        text: model.tag
                        color: {
                            switch(model.level) {
                            case "ok":   return "#00e5a0"
                            case "err":  return "#ff5f5f"
                            case "warn": return "#ffb547"
                            case "sys":  return "#7c6bff"
                            default:     return "#5a5f6e"
                            }
                        }
                        font.pixelSize: 11; font.family: "Courier New"
                        font.weight: Font.Bold
                    }

                    // Mesaj
                    Text {
                        text: model.message
                        color: "#e8eaf2"; font.pixelSize: 11
                        font.family: "Courier New"
                        wrapMode: Text.Wrap
                        width: parent.width - 130
                    }
                }

                ScrollBar.vertical: ScrollBar {
                    width: 3
                    contentItem: Rectangle { radius: 1.5; color: "#383d50" }
                }
            }

            // ─── Input sıra ────────────────────────────────────────────────
            Rectangle {
                Layout.fillWidth: true
                height: 44
                color: "#0c0e18"
                border.color: "rgba(255,255,255,0.07)"; border.width: 1

                RowLayout {
                    anchors { fill: parent; leftMargin: 12; rightMargin: 8; topMargin: 6; bottomMargin: 6 }
                    spacing: 8

                    Text { text: "$ "; color: "#7c6bff"; font.pixelSize: 13; font.family: "Courier New" }

                    TextField {
                        id: termInput
                        Layout.fillWidth: true
                        background: Item {}
                        color: "#e8eaf2"; font.pixelSize: 13; font.family: "Courier New"
                        placeholderText: "Əmr daxil edin..."
                        placeholderTextColor: "#383d50"
                        inputMethodHints: Qt.ImhNoPredictiveText
                        onAccepted: {
                            if (text.trim().length > 0) {
                                app.sendTerminalCommand(text.trim())
                                text = ""
                            }
                        }
                    }

                    // Göndər düyməsi (↵)
                    Rectangle {
                        width: 32; height: 32; radius: 7
                        color: "#7c6bff"
                        Text {
                            anchors.centerIn: parent
                            text: "↵"; color: "#fff"
                            font.pixelSize: 14
                        }
                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                if (termInput.text.trim().length > 0) {
                                    app.sendTerminalCommand(termInput.text.trim())
                                    termInput.text = ""
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
