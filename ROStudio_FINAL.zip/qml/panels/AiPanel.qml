// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — AiPanel.qml
//  HTML #panel-ai-ın tam QML qarşılığı
//  Claude AI söhbət interfeysi
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    color: "transparent"

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        // ─── Sürüşdürülə bilən söhbət siyahısı ──────────────────────────────
        ListView {
            id: chatList
            Layout.fillWidth: true
            Layout.fillHeight: true
            model: app.aiChat
            clip: true
            topMargin: 14; bottomMargin: 14
            leftMargin: 14; rightMargin: 14
            spacing: 12

            // Yeni mesaj əlavə olunanda aşağı sürüş
            Connections {
                target: app.aiChat
                function onMessageAdded() { chatList.positionViewAtEnd() }
            }

            header: Item {
                width: chatList.width - 28
                height: greetBox.implicitHeight + 20

                // Salamlama kartı (JS: ai-greet mesajı)
                Rectangle {
                    id: greetBox
                    anchors { left: parent.left; right: parent.right; top: parent.top; topMargin: 6 }
                    radius: 12
                    color: "rgba(124,107,255,0.08)"
                    border.color: "rgba(124,107,255,0.2)"; border.width: 1
                    implicitHeight: greetCol.implicitHeight + 20

                    ColumnLayout {
                        id: greetCol
                        anchors { left: parent.left; right: parent.right; margins: 14; top: parent.top; topMargin: 14 }
                        spacing: 6

                        Row {
                            spacing: 8
                            Text { text: "🤖"; font.pixelSize: 18 }
                            Text {
                                text: "ROStudio AI"
                                color: "#7c6bff"; font.pixelSize: 13; font.weight: Font.Bold
                                anchors.verticalCenter: parent.verticalCenter
                            }
                        }

                        Text {
                            text: app.tr.t("ai-greet")
                            color: "#e8eaf2"; font.pixelSize: 13
                            wrapMode: Text.WordWrap
                            Layout.fillWidth: true
                        }
                    }
                }
            }

            delegate: RowLayout {
                width: chatList.width - 28
                layoutDirection: model.role === "user" ? Qt.RightToLeft : Qt.LeftToRight

                // Mesaj balonu
                Rectangle {
                    radius: 12
                    color: model.role === "user" ? "#7c6bff" : "#131620"
                    border.color: model.role === "user" ? "transparent" : "rgba(255,255,255,0.07)"
                    border.width: 1
                    implicitWidth: Math.min(msgText.implicitWidth + 24, chatList.width * 0.82)
                    implicitHeight: msgText.implicitHeight + 20

                    Text {
                        id: msgText
                        anchors { fill: parent; margins: 12 }
                        text: model.text
                        color: model.role === "user" ? "#ffffff" : "#e8eaf2"
                        font.pixelSize: 13
                        wrapMode: Text.WordWrap
                        textFormat: Text.MarkdownText
                        lineHeight: 1.4
                    }
                }

                Item { Layout.fillWidth: true }
            }

            // "AI düşünür" animasiyası
            footer: Item {
                visible: app.aiChat.thinking
                height: visible ? 50 : 0
                width: chatList.width - 28

                Rectangle {
                    anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                    radius: 12; height: 36; width: 80
                    color: "#131620"
                    border.color: "rgba(255,255,255,0.07)"; border.width: 1

                    Row {
                        anchors.centerIn: parent; spacing: 5
                        Repeater {
                            model: 3
                            Rectangle {
                                width: 6; height: 6; radius: 3; color: "#7c6bff"
                                SequentialAnimation on opacity {
                                    loops: Animation.Infinite
                                    PauseAnimation { duration: index * 200 }
                                    NumberAnimation { to: 0.2; duration: 300 }
                                    NumberAnimation { to: 1.0; duration: 300 }
                                }
                            }
                        }
                    }
                }
            }

            ScrollBar.vertical: ScrollBar {
                width: 3
                contentItem: Rectangle { radius: 1.5; color: "#383d50" }
            }
        }

        // ─── Sürətli suallar ────────────────────────────────────────────────
        ScrollView {
            Layout.fillWidth: true
            height: 42
            ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
            ScrollBar.vertical.policy: ScrollBar.AlwaysOff

            Row {
                spacing: 8; leftPadding: 14; rightPadding: 14; height: parent.height

                Repeater {
                    model: [
                        { key: "ai-q-drop", icon: "📉" },
                        { key: "ai-q-rev",  icon: "💰" },
                        { key: "ai-q-err",  icon: "🐛" },
                        { key: "ai-q-fore", icon: "📈" },
                        { key: "ai-q-ds",   icon: "🗄" },
                    ]

                    delegate: Rectangle {
                        height: 30; radius: 15
                        color: "#1a1d2b"
                        border.color: "rgba(255,255,255,0.07)"; border.width: 1
                        implicitWidth: qRow.implicitWidth + 20

                        Row {
                            id: qRow; anchors.centerIn: parent; spacing: 5
                            Text { text: modelData.icon; font.pixelSize: 12 }
                            Text {
                                text: app.tr.t(modelData.key)
                                color: "#5a5f6e"; font.pixelSize: 11
                            }
                        }

                        MouseArea {
                            anchors.fill: parent
                            onClicked: app.sendAiMessage(app.tr.t(modelData.key))
                        }
                    }
                }
            }
        }

        // ─── Mesaj yazma sahəsi ─────────────────────────────────────────────
        Rectangle {
            Layout.fillWidth: true
            height: 56
            color: "#131620"
            border.color: "rgba(255,255,255,0.07)"; border.width: 1

            RowLayout {
                anchors { fill: parent; leftMargin: 14; rightMargin: 12; topMargin: 8; bottomMargin: 8 }
                spacing: 10

                TextField {
                    id: aiInput
                    Layout.fillWidth: true
                    background: Rectangle {
                        radius: 10; color: "#1a1d2b"
                        border.color: parent.activeFocus ? "rgba(124,107,255,0.45)" : "rgba(255,255,255,0.07)"
                        border.width: 1
                    }
                    leftPadding: 14; rightPadding: 14
                    placeholderText: "Sual yazın..."
                    placeholderTextColor: "#383d50"
                    color: "#e8eaf2"; font.pixelSize: 14
                    enabled: !app.aiChat.thinking
                    onAccepted: sendAiMsg()
                }

                // Göndər düyməsi
                Rectangle {
                    width: 38; height: 38; radius: 10
                    color: aiInput.text.trim().length > 0 && !app.aiChat.thinking
                           ? "#7c6bff" : "#1a1d2b"
                    Behavior on color { ColorAnimation { duration: 200 } }

                    Text {
                        anchors.centerIn: parent
                        text: app.aiChat.thinking ? "⏳" : "↑"
                        color: "#fff"; font.pixelSize: 16; font.weight: Font.Bold
                    }

                    MouseArea {
                        anchors.fill: parent
                        onClicked: sendAiMsg()
                    }
                }
            }
        }
    }

    function sendAiMsg() {
        const msg = aiInput.text.trim()
        if (msg.length > 0 && !app.aiChat.thinking) {
            app.sendAiMessage(msg)
            aiInput.text = ""
        }
    }
}
