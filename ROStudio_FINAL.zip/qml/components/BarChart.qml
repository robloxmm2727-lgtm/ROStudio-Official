// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — BarChart.qml
//  HTML .chart-wrap + Canvas ilə çizilən bar qrafiki
//  JS-dəki buildChart() funksiyasının QML qarşılığı
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: chartWrap
    implicitHeight: 130
    radius: 14
    color: "#131620"
    border.color: "rgba(255,255,255,0.07)"; border.width: 1

    property string  title:     "Visits per day"
    property var     chartData: []   // QVector<int> → JS array

    // Məlumat dəyişdikdə yenidən çiz
    onChartDataChanged: barsCanvas.requestPaint()

    ColumnLayout {
        anchors { fill: parent; margins: 14 }
        spacing: 8

        // Başlıq
        RowLayout {
            Layout.fillWidth: true
            ColumnLayout {
                spacing: 2
                Text { text: chartWrap.title; color: "#e8eaf2"; font.pixelSize: 13; font.weight: Font.DemiBold }
                Text {
                    text: chartWrap.chartData.length > 0
                          ? "Cari: " + chartWrap.chartData[chartWrap.chartData.length - 1] + " online"
                          : "Məlumat gözlənilir..."
                    color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New"
                }
            }
            // Legend
            Row {
                spacing: 10; Layout.alignment: Qt.AlignRight | Qt.AlignVCenter
                Row { spacing: 4
                    Rectangle { width: 6; height: 6; radius: 3; color: "#00e5a0"; anchors.verticalCenter: parent.verticalCenter }
                    Text { text: app.tr.t("chart-today"); color: "#5a5f6e"; font.pixelSize: 9; font.family: "Courier New" }
                }
                Row { spacing: 4
                    Rectangle { width: 6; height: 6; radius: 3; color: "#7c6bff"; anchors.verticalCenter: parent.verticalCenter }
                    Text { text: app.tr.t("chart-prev"); color: "#5a5f6e"; font.pixelSize: 9; font.family: "Courier New" }
                }
            }
        }

        // Canvas bar qrafiki
        Canvas {
            id: barsCanvas
            Layout.fillWidth: true
            implicitHeight: 65

            onPaint: {
                const ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)

                const data = chartWrap.chartData
                if (!data || data.length === 0) {
                    ctx.fillStyle = "#5a5f6e"
                    ctx.font = "11px Courier New"
                    ctx.fillText("Məlumat yoxdur — 30s-dən sonra yenilənir", 10, height / 2)
                    return
                }

                const max  = Math.max(...data, 1)
                const n    = data.length
                const gap  = 5
                const barW = (width - gap * (n - 1)) / n

                data.forEach(function(v, i) {
                    const barH  = Math.round((v / max) * (height - 10))
                    const x     = i * (barW + gap)
                    const y     = height - barH
                    const isNow = (i === n - 1)

                    ctx.fillStyle = isNow ? "#00e5a0" : "rgba(124,107,255,0.5)"
                    ctx.beginPath()
                    ctx.roundRect(x, y, barW, barH, [3, 3, 0, 0])
                    ctx.fill()
                })
            }
        }
    }
}
