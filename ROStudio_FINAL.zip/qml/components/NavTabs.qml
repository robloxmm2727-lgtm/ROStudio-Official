// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — NavTabs.qml
//  HTML .nav-tabs-ın QML qarşılığı — üfüqi sürüşdürülə bilən tab sırası
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15

Rectangle {
    implicitHeight: 54
    color: "#131620"
    border.color: "rgba(255,255,255,0.07)"; border.width: 1

    // Tab məlumatları (JS: nav-tabs içindəki button-ların C++ qarşılığı)
    property var tabs: [
        { icon: "📊", labelKey: "nav-dashboard", panel: "dashboard" },
        { icon: "⌨",  labelKey: "nav-terminal",  panel: "terminal"  },
        { icon: "🗄",  labelKey: "nav-datastore", panel: "datastore" },
        { icon: "🤖", labelKey: "nav-ai",         panel: "ai"        },
        { icon: "📢", labelKey: "nav-announce",   panel: "announce"  },
        { icon: "👥", labelKey: "nav-collab",     panel: "collab"    },
        { icon: "⚙",  labelKey: "nav-settings",  panel: "settings"  },
    ]

    ScrollView {
        anchors.fill: parent
        ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
        ScrollBar.vertical.policy: ScrollBar.AlwaysOff
        clip: true

        Row {
            id: tabRow
            height: parent.height
            spacing: 0

            Repeater {
                model: tabs

                delegate: Rectangle {
                    width: tabContent.implicitWidth + 28
                    height: 54
                    color: app.activePanel === modelData.panel
                           ? "rgba(124,107,255,0.05)" : "transparent"

                    // Alt xətt (aktiv tab üçün)
                    Rectangle {
                        anchors { bottom: parent.bottom; left: parent.left; right: parent.right }
                        height: 2
                        color: app.activePanel === modelData.panel ? "#7c6bff" : "transparent"
                    }

                    Column {
                        id: tabContent
                        anchors.centerIn: parent
                        spacing: 2

                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: modelData.icon
                            font.pixelSize: 16
                        }
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: app.tr.t(modelData.labelKey)
                            color: app.activePanel === modelData.panel ? "#7c6bff" : "#5a5f6e"
                            font.pixelSize: 9
                            font.family: "Courier New"
                            font.letterSpacing: 0.5
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        onClicked: app.switchPanel(modelData.panel)
                        onPressed: parent.opacity = 0.7
                        onReleased: parent.opacity = 1.0
                    }

                    Behavior on color { ColorAnimation { duration: 150 } }
                }
            }
        }
    }
}
