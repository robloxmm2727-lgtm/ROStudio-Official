// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — ApiModal.qml
//  HTML #api-modal-ın QML qarşılığı
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Overlay.modal: Rectangle { color: "rgba(0,0,0,0.6)" }

Popup {
    id: apiModal
    anchors.centerIn: parent
    width: Math.min(parent ? parent.width - 32 : 360, 400)
    modal: true
    closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

    background: Rectangle {
        color: "#131620"
        radius: 16
        border.color: "rgba(124,107,255,0.3)"; border.width: 1
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 20
        spacing: 16

        // Başlıq
        ColumnLayout {
            spacing: 4
            Text {
                text: app.tr.t("modal-api-title")
                color: "#e8eaf2"; font.pixelSize: 16; font.weight: Font.Bold
            }
            Text {
                text: app.tr.t("modal-api-sub")
                color: "#5a5f6e"; font.pixelSize: 12; font.family: "Courier New"
            }
        }

        // API Key sahəsi
        ColumnLayout {
            Layout.fillWidth: true; spacing: 6
            Text { text: "ROBLOX API KEY"; color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New"; letterSpacing: 0.8 }
            Rectangle {
                Layout.fillWidth: true; height: 44; radius: 9
                color: "#1a1d2b"; border.color: "rgba(255,255,255,0.07)"; border.width: 1
                TextField {
                    id: modalApiKey
                    anchors.fill: parent; anchors.margins: 1
                    leftPadding: 12; rightPadding: 12
                    echoMode: TextField.Password
                    placeholderText: "Yeni API açarı (boş = dəyişmə)"
                    placeholderTextColor: "#383d50"
                    color: "#e8eaf2"; font.pixelSize: 13
                    background: Item {}
                }
            }
        }

        // Universe ID sahəsi
        ColumnLayout {
            Layout.fillWidth: true; spacing: 6
            Text { text: "UNIVERSE ID"; color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New"; letterSpacing: 0.8 }
            Rectangle {
                Layout.fillWidth: true; height: 44; radius: 9
                color: "#1a1d2b"; border.color: "rgba(255,255,255,0.07)"; border.width: 1
                TextField {
                    id: modalUid
                    anchors.fill: parent; anchors.margins: 1
                    leftPadding: 12; rightPadding: 12
                    text: app.universeId
                    color: "#e8eaf2"; font.pixelSize: 13
                    background: Item {}
                    inputMethodHints: Qt.ImhDigitsOnly
                }
            }
        }

        // Saxla düyməsi
        Rectangle {
            Layout.fillWidth: true; height: 46; radius: 10
            color: "#7c6bff"
            Text {
                anchors.centerIn: parent
                text: app.tr.t("btn-save-api")
                color: "#fff"; font.pixelSize: 14; font.weight: Font.Bold
            }
            MouseArea {
                anchors.fill: parent
                onClicked: {
                    app.saveNewCredentials(modalApiKey.text, modalUid.text, "")
                    apiModal.close()
                }
            }
        }

        // Bağla düyməsi
        Rectangle {
            Layout.fillWidth: true; height: 44; radius: 10
            color: "rgba(255,255,255,0.04)"
            border.color: "rgba(255,255,255,0.07)"; border.width: 1
            Text { anchors.centerIn: parent; text: "Ləğv et"; color: "#5a5f6e"; font.pixelSize: 13 }
            MouseArea { anchors.fill: parent; onClicked: apiModal.close() }
        }
    }
}
