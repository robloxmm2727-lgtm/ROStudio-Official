// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — MainScreen.qml
//  HTML #screen-main-ın tam QML qarşılığı
//  TopBar + NavTabs + Panel sistemi
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: root
    color: "#0d0f18"   // --bg-base

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        // ─── Top Bar ────────────────────────────────────────────────────────
        TopBar { Layout.fillWidth: true }

        // ─── Nav Tabs ────────────────────────────────────────────────────────
        NavTabs { Layout.fillWidth: true }

        // ─── Panel konteyner (StackLayout ilə) ───────────────────────────────
        StackLayout {
            id: panelStack
            Layout.fillWidth: true
            Layout.fillHeight: true

            // Panel indeksi (JS: activePanel-a uyğun)
            property var panelNames: ["dashboard","terminal","datastore","ai","announce","collab","settings"]

            currentIndex: panelNames.indexOf(app.activePanel)

            // Panel 0 — Dashboard
            Flickable {
                contentHeight: dashPanel.implicitHeight + 28
                clip: true
                DashboardPanel {
                    id: dashPanel
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                }
            }

            // Panel 1 — Terminal
            Flickable {
                contentHeight: termPanel.implicitHeight + 28
                clip: true
                TerminalPanel {
                    id: termPanel
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                }
            }

            // Panel 2 — DataStore
            Flickable {
                contentHeight: dsPanel.implicitHeight + 28
                clip: true
                DataStorePanel {
                    id: dsPanel
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                }
            }

            // Panel 3 — AI Chat
            AiPanel {
                // Tam ekran, scroll daxildir
            }

            // Panel 4 — Announce
            Flickable {
                contentHeight: annPanel.implicitHeight + 28
                clip: true
                AnnouncePanel {
                    id: annPanel
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                }
            }

            // Panel 5 — Team / Collab
            Flickable {
                contentHeight: teamPanel.implicitHeight + 28
                clip: true
                TeamPanel {
                    id: teamPanel
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                }
            }

            // Panel 6 — Settings
            Flickable {
                contentHeight: settingsPanel.implicitHeight + 28
                clip: true
                SettingsPanel {
                    id: settingsPanel
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                }
            }
        }
    }

    // ─── API Key Modal ───────────────────────────────────────────────────────
    ApiModal { id: apiModal }
}
