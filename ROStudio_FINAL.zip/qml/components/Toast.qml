// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — Toast.qml
//  JS showToast()-ın QML qarşılığı
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15

Rectangle {
    id: toast
    width: toastText.implicitWidth + 32
    height: 38
    radius: 19
    opacity: 0
    visible: opacity > 0

    color: {
        switch(toastType) {
        case "success": return "rgba(0,229,160,0.15)"
        case "error":   return "rgba(255,95,95,0.15)"
        default:        return "rgba(124,107,255,0.15)"
        }
    }
    border.color: {
        switch(toastType) {
        case "success": return "rgba(0,229,160,0.4)"
        case "error":   return "rgba(255,95,95,0.4)"
        default:        return "rgba(124,107,255,0.4)"
        }
    }
    border.width: 1

    property string toastMsg: ""
    property string toastType: "info"

    Text {
        id: toastText
        anchors.centerIn: parent
        text: toast.toastMsg
        color: {
            switch(toast.toastType) {
            case "success": return "#00e5a0"
            case "error":   return "#ff5f5f"
            default:        return "#7c6bff"
            }
        }
        font.pixelSize: 13; font.weight: Font.Medium
    }

    // JS: setTimeout 2500ms
    Timer {
        id: hideTimer
        interval: 2500
        onTriggered: hideAnim.start()
    }

    NumberAnimation { id: showAnim; target: toast; property: "opacity"; to: 1.0; duration: 200 }
    NumberAnimation { id: hideAnim; target: toast; property: "opacity"; to: 0.0; duration: 300 }

    function show(msg, type) {
        toastMsg  = msg
        toastType = type || "info"
        hideAnim.stop()
        showAnim.start()
        hideTimer.restart()
    }
}
