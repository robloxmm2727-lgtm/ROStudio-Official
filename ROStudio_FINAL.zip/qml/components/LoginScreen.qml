// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — LoginScreen.qml
//  HTML #screen-login-ın tam QML qarşılığı
//  Animasiyalar: orb-breathe, ring-spin, pulse
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: root
    color: "#080a10"
    clip: true

    // ─── Fon grid animasiyası (CSS ::before grid) ────────────────────────────
    Canvas {
        anchors.fill: parent
        opacity: 0.4
        onPaint: {
            const ctx = getContext("2d")
            ctx.clearRect(0, 0, width, height)
            ctx.strokeStyle = "rgba(124,107,255,0.05)"
            ctx.lineWidth = 1
            const step = 40
            for (let x = 0; x < width; x += step) {
                ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,height); ctx.stroke()
            }
            for (let y = 0; y < height; y += step) {
                ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(width,y); ctx.stroke()
            }
        }
    }

    // ─── Üst Glow Orb ─────────────────────────────────────────────────────────
    Rectangle {
        width: 340; height: 340
        x: parent.width/2 - 170
        y: -120
        radius: 170
        color: "transparent"

        RadialGradient {
            anchors.fill: parent
            gradient: Gradient {
                GradientStop { position: 0.0; color: "rgba(124,107,255,0.18)" }
                GradientStop { position: 1.0; color: "transparent" }
            }
        }

        SequentialAnimation on opacity {
            loops: Animation.Infinite
            NumberAnimation { to: 1.0; duration: 2000; easing.type: Easing.InOutSine }
            NumberAnimation { to: 0.7; duration: 2000; easing.type: Easing.InOutSine }
        }
    }

    // ─── Mərkəzi kart ────────────────────────────────────────────────────────
    Flickable {
        anchors.fill: parent
        contentHeight: content.implicitHeight + 48
        clip: true

        ColumnLayout {
            id: content
            anchors.centerIn: parent
            width: Math.min(parent.width - 40, 400)
            spacing: 0

            // ── Logo bloku ───────────────────────────────────────────────────
            Item {
                Layout.alignment: Qt.AlignHCenter
                Layout.bottomMargin: 36
                implicitWidth: 72; implicitHeight: 72 + 80

                // Xarici halqa animasiyası (ring-spin)
                Rectangle {
                    id: outerRing
                    width: 72; height: 72
                    radius: 36
                    color: "transparent"
                    border.color: "#7c6bff"; border.width: 1.5
                    opacity: 0.5
                    RotationAnimation on rotation {
                        loops: Animation.Infinite; duration: 8000
                        from: 0; to: 360
                    }
                }

                // Daxili nöqtəli halqa (ring-spin reverse)
                Rectangle {
                    x: 6; y: 6
                    width: 60; height: 60; radius: 30
                    color: "transparent"
                    border.color: "rgba(124,107,255,0.3)"; border.width: 1
                    RotationAnimation on rotation {
                        loops: Animation.Infinite; duration: 5000
                        from: 360; to: 0
                    }
                }

                // Mərkəz disk (accent gradient)
                Rectangle {
                    x: 14; y: 14; width: 44; height: 44; radius: 22
                    gradient: Gradient {
                        orientation: Gradient.Diagonal
                        GradientStop { position: 0.0; color: "#7c6bff" }
                        GradientStop { position: 1.0; color: "#5040cc" }
                    }
                    // Ağ nöqtə
                    Rectangle {
                        anchors.centerIn: parent
                        width: 10; height: 10; radius: 5
                        color: "#ffffff"
                        layer.enabled: true
                        layer.effect: null
                    }
                }

                // Mətn bloku
                ColumnLayout {
                    anchors.top: outerRing.bottom
                    anchors.topMargin: 16
                    anchors.horizontalCenter: outerRing.horizontalCenter
                    spacing: 4

                    Row {
                        Layout.alignment: Qt.AlignHCenter
                        Text { text: "RO";      color: "#ffffff";   font.pixelSize: 38; font.weight: Font.Black; font.letterSpacing: -1.5 }
                        Text { text: "Studio";  color: "#7c6bff";   font.pixelSize: 38; font.weight: Font.Black; font.letterSpacing: -1.5 }
                    }

                    Text {
                        Layout.alignment: Qt.AlignHCenter
                        text: app.tr.t("lg-tagline")
                        color: "#5a5f6e"; font.pixelSize: 12
                    }

                    // Version badge (pulse animasiyası)
                    Rectangle {
                        Layout.alignment: Qt.AlignHCenter
                        height: 24; radius: 12
                        color: "rgba(255,255,255,0.04)"
                        border.color: "rgba(255,255,255,0.07)"; border.width: 1
                        implicitWidth: versionRow.implicitWidth + 24

                        Row {
                            id: versionRow
                            anchors.centerIn: parent
                            spacing: 6
                            // Yaşıl nöqtə (pulse)
                            Rectangle {
                                width: 5; height: 5; radius: 2.5
                                color: "#00e5a0"
                                anchors.verticalCenter: parent.verticalCenter
                                SequentialAnimation on opacity {
                                    loops: Animation.Infinite
                                    NumberAnimation { to: 0.3; duration: 1000 }
                                    NumberAnimation { to: 1.0; duration: 1000 }
                                }
                            }
                            Text {
                                text: "v5.0.0 · CyberWeld"
                                color: "#5a5f6e"; font.pixelSize: 11
                                font.family: "Courier New"
                            }
                        }
                    }
                }
            }

            // ── Dil seçimi ───────────────────────────────────────────────────
            Rectangle {
                Layout.fillWidth: true
                Layout.bottomMargin: 20
                height: 44; radius: 9
                color: "#1a1d2b"
                border.color: "rgba(255,255,255,0.07)"; border.width: 1

                ComboBox {
                    anchors.fill: parent
                    model: ["English (en)", "Azərbaycanca (az)", "Türkçe (tr)", "Русский (ru)"]
                    property var codes: ["en", "az", "tr", "ru"]
                    background: Item {}
                    contentItem: Text {
                        leftPadding: 14
                        text: parent.currentText
                        color: "#e8eaf2"; font.pixelSize: 13
                        verticalAlignment: Text.AlignVCenter
                    }
                    onCurrentIndexChanged: app.setLanguage(codes[currentIndex])
                }
            }

            // ── Etimadnamə kartı ─────────────────────────────────────────────
            Rectangle {
                Layout.fillWidth: true
                Layout.bottomMargin: 14
                radius: 14
                color: "#131620"
                border.color: "rgba(255,255,255,0.07)"; border.width: 1
                implicitHeight: cardCol.implicitHeight + 44

                ColumnLayout {
                    id: cardCol
                    anchors { left: parent.left; right: parent.right; top: parent.top
                              margins: 18; topMargin: 22 }
                    spacing: 14

                    // Kart başlığı
                    Row {
                        spacing: 8
                        Rectangle { width: 3; height: 12; radius: 1; color: "#7c6bff"; anchors.verticalCenter: parent.verticalCenter }
                        Text {
                            text: app.tr.t("lg-card-title").toUpperCase()
                            color: "#5a5f6e"; font.pixelSize: 11; font.family: "Courier New"
                            letterSpacing: 1
                        }
                    }

                    // API Açarı sahəsi
                    ColumnLayout {
                        Layout.fillWidth: true; spacing: 7
                        Text {
                            text: app.tr.t("lg-lbl-apikey")
                            color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New"
                            letterSpacing: 0.8
                        }
                        Rectangle {
                            Layout.fillWidth: true; height: 46; radius: 9
                            color: "#1a1d2b"
                            border.color: apiKeyField.activeFocus ? "rgba(124,107,255,0.45)" : "rgba(255,255,255,0.07)"
                            border.width: 1
                            TextField {
                                id: apiKeyField
                                anchors { fill: parent; leftMargin: 14; rightMargin: 42 }
                                placeholderText: "rblx_••••••••••••••••••••••••••"
                                echoMode: TextField.Password
                                color: "#e8eaf2"; font.pixelSize: 14
                                background: Item {}
                                placeholderTextColor: "#383d50"
                            }
                            // Göstər/gizlət düyməsi (JS: togglePass)
                            Text {
                                anchors { right: parent.right; rightMargin: 13; verticalCenter: parent.verticalCenter }
                                text: apiKeyField.echoMode === TextField.Password ? "👁" : "🙈"
                                font.pixelSize: 15; color: "#5a5f6e"
                                MouseArea {
                                    anchors.fill: parent
                                    onClicked: apiKeyField.echoMode =
                                        apiKeyField.echoMode === TextField.Password
                                            ? TextField.Normal : TextField.Password
                                }
                            }
                        }
                    }

                    // Universe ID sahəsi
                    ColumnLayout {
                        Layout.fillWidth: true; spacing: 7
                        Text {
                            text: app.tr.t("lg-lbl-uid")
                            color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New"
                            letterSpacing: 0.8
                        }
                        Rectangle {
                            Layout.fillWidth: true; height: 46; radius: 9
                            color: "#1a1d2b"
                            border.color: uidField.activeFocus ? "rgba(124,107,255,0.45)" : "rgba(255,255,255,0.07)"
                            border.width: 1
                            TextField {
                                id: uidField
                                anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                                placeholderText: "123456789"
                                color: "#e8eaf2"; font.pixelSize: 14
                                background: Item {}
                                placeholderTextColor: "#383d50"
                                inputMethodHints: Qt.ImhDigitsOnly
                            }
                        }
                    }

                    // Place ID sahəsi (optional)
                    ColumnLayout {
                        Layout.fillWidth: true; spacing: 7
                        Text {
                            text: app.tr.t("lg-lbl-pid") + " (optional)"
                            color: "#5a5f6e"; font.pixelSize: 10; font.family: "Courier New"
                            letterSpacing: 0.8
                        }
                        Rectangle {
                            Layout.fillWidth: true; height: 46; radius: 9
                            color: "#1a1d2b"
                            border.color: pidField.activeFocus ? "rgba(124,107,255,0.45)" : "rgba(255,255,255,0.07)"
                            border.width: 1
                            TextField {
                                id: pidField
                                anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                                placeholderText: "87654321"
                                color: "#e8eaf2"; font.pixelSize: 14
                                background: Item {}
                                placeholderTextColor: "#383d50"
                                inputMethodHints: Qt.ImhDigitsOnly
                            }
                        }
                    }
                }
            }

            // ── Təhlükəsizlik çipi (AES-256 badge) ──────────────────────────
            Rectangle {
                Layout.fillWidth: true; Layout.bottomMargin: 20
                height: 50; radius: 9
                color: "rgba(0,229,160,0.06)"
                border.color: "rgba(0,229,160,0.15)"; border.width: 1

                Row {
                    anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter }
                    spacing: 10
                    Text { text: "🔒"; font.pixelSize: 16; color: "#00e5a0" }
                    Text {
                        text: app.tr.t("lg-security")
                        color: "rgba(0,229,160,0.8)"; font.pixelSize: 11
                        font.family: "Courier New"; wrapMode: Text.WordWrap
                        width: root.width - 100
                    }
                }
            }

            // ── Xəta mesajı ──────────────────────────────────────────────────
            Rectangle {
                id: errorBox
                Layout.fillWidth: true; Layout.bottomMargin: 14
                height: 40; radius: 9
                color: "rgba(255,95,95,0.08)"
                border.color: "rgba(255,95,95,0.2)"; border.width: 1
                visible: false

                Text {
                    id: errorText
                    anchors.centerIn: parent
                    color: "#ff5f5f"; font.pixelSize: 12; font.family: "Courier New"
                    horizontalAlignment: Text.AlignHCenter
                }
            }

            // ── Giriş düyməsi ────────────────────────────────────────────────
            Rectangle {
                Layout.fillWidth: true; Layout.bottomMargin: 14
                height: 52; radius: 14
                color: "#7c6bff"
                layer.enabled: true

                // Gradient overlay
                Rectangle {
                    anchors.fill: parent; radius: parent.radius
                    gradient: Gradient {
                        orientation: Gradient.Diagonal
                        GradientStop { position: 0.0; color: "rgba(255,255,255,0.12)" }
                        GradientStop { position: 1.0; color: "transparent" }
                    }
                }

                Text {
                    anchors.centerIn: parent
                    text: loginBusy ? "" : app.tr.t("btn-login-text")
                    color: "#ffffff"; font.pixelSize: 15; font.weight: Font.Bold
                }

                BusyIndicator {
                    anchors.centerIn: parent
                    running: loginBusy; visible: loginBusy
                    implicitWidth: 24; implicitHeight: 24
                }

                property bool loginBusy: false

                MouseArea {
                    anchors.fill: parent
                    onPressed: parent.scale = 0.98
                    onReleased: parent.scale = 1.0
                    onClicked: {
                        errorBox.visible = false
                        app.doLogin(apiKeyField.text, uidField.text, pidField.text)
                    }
                }

                Behavior on scale { NumberAnimation { duration: 100 } }
            }

            // ── Xəbərlər ────────────────────────────────────────────────────
            Text {
                Layout.alignment: Qt.AlignHCenter
                text: "by CyberWeld · <a href='https://roblox.com'>Roblox Open Cloud</a>"
                color: "#5a5f6e"; font.pixelSize: 11
                onLinkActivated: Qt.openUrlExternally(link)
                textFormat: Text.RichText
            }
        }
    }

    // ─── loginFailed siqnalına reaksiya ───────────────────────────────────────
    Connections {
        target: app
        function onLoginFailed(reason) {
            errorText.text = reason
            errorBox.visible = true
        }
    }
}
