// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — GameCard.qml
//  HTML .game-card-ın QML qarşılığı
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: card
    implicitHeight: 90
    radius: 14
    color: "#131620"
    border.color: pressed ? "rgba(124,107,255,0.45)" : "rgba(255,255,255,0.07)"
    border.width: 1

    property string gameName: "Yüklənir..."
    property int    players:  0
    property int    servers:  0
    property var    visits:   "0"
    property bool   isLive:   true
    property bool   pressed:  false

    Behavior on border.color { ColorAnimation { duration: 150 } }

    ColumnLayout {
        anchors { fill: parent; margins: 14 }
        spacing: 12

        // Başlıq sıra
        RowLayout {
            Layout.fillWidth: true

            Text {
                text: card.gameName
                color: "#e8eaf2"; font.pixelSize: 15; font.weight: Font.Bold
                Layout.fillWidth: true
                elide: Text.ElideRight
            }

            // LIVE badge
            Rectangle {
                visible: card.isLive
                height: 20; radius: 10
                color: "rgba(0,229,160,0.08)"
                border.color: "rgba(0,229,160,0.2)"; border.width: 1
                implicitWidth: liveBadgeRow.implicitWidth + 16

                Row {
                    id: liveBadgeRow
                    anchors.centerIn: parent; spacing: 4

                    Rectangle {
                        width: 5; height: 5; radius: 2.5; color: "#00e5a0"
                        anchors.verticalCenter: parent.verticalCenter
                        SequentialAnimation on opacity {
                            loops: Animation.Infinite
                            NumberAnimation { to: 0.3; duration: 750 }
                            NumberAnimation { to: 1.0; duration: 750 }
                        }
                    }
                    Text { text: "LIVE"; color: "#00e5a0"; font.pixelSize: 9; font.family: "Courier New" }
                }
            }
        }

        // Mini stat-lar: Players | Servers | Visits
        RowLayout {
            Layout.fillWidth: true

            Repeater {
                model: [
                    { lbl: qsTr("Players"), val: card.players.toLocaleString() },
                    { lbl: qsTr("Servers"), val: card.servers > 0 ? card.servers.toString() : "—" },
                    { lbl: qsTr("Visits"),  val: card.visits.toString() },
                ]
                delegate: ColumnLayout {
                    Layout.fillWidth: true; spacing: 3
                    Text {
                        Layout.alignment: Qt.AlignHCenter
                        text: modelData.lbl
                        color: "#5a5f6e"; font.pixelSize: 9; font.family: "Courier New"
                    }
                    Text {
                        Layout.alignment: Qt.AlignHCenter
                        text: modelData.val
                        color: "#e8eaf2"; font.pixelSize: 14; font.weight: Font.Bold
                        font.family: "Courier New"
                    }
                }
            }
        }
    }

    MouseArea {
        anchors.fill: parent
        onPressed:  card.pressed = true
        onReleased: card.pressed = false
        onClicked:  {} // Gələcəkdə oyun detaylarına keçid
    }
}
