// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — StatCard.qml
//  HTML .stat-card-ın QML qarşılığı
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15

Rectangle {
    id: card
    implicitHeight: 90
    radius: 14
    color: "#131620"
    border.color: "rgba(255,255,255,0.07)"; border.width: 1
    clip: true

    property string icon:        "📊"
    property string label:       "Label"
    property string value:       "0"
    property string delta:       ""
    property bool   deltaUp:     false
    property color  accentColor: "#7c6bff"

    // Üst rəngli xətt (stat-card::before)
    Rectangle {
        anchors { top: parent.top; left: parent.left; right: parent.right }
        height: 2; radius: 1
        color: card.accentColor
    }

    Column {
        anchors { left: parent.left; leftMargin: 13; top: parent.top; topMargin: 13 }
        spacing: 4

        Text { text: card.icon; font.pixelSize: 20 }

        Text {
            text: card.label
            color: "#5a5f6e"; font.pixelSize: 9
            font.family: "Courier New"
            font.letterSpacing: 0.5
            font.capitalization: Font.AllUppercase
        }

        Text {
            text: card.value
            color: card.accentColor
            font.pixelSize: 24; font.weight: Font.Black
            font.letterSpacing: -1
        }

        Text {
            text: card.delta
            color: card.deltaUp ? "#00e5a0" : "#5a5f6e"
            font.pixelSize: 10; font.family: "Courier New"
        }
    }
}
