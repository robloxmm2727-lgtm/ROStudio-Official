// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio — TopBar.qml
//  HTML .top-bar-ın QML qarşılığı
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15

Rectangle {
    implicitHeight: 54
    color: "#131620"   // --bg-card
    border.color: "rgba(255,255,255,0.07)"; border.width: 1

    Row {
        anchors { left: parent.left; leftMargin: 16; verticalCenter: parent.verticalCenter }
        spacing: 0
        Text { text: "RO";     color: "#ffffff"; font.pixelSize: 17; font.weight: Font.Black; font.letterSpacing: -0.5 }
        Text { text: "Studio"; color: "#7c6bff"; font.pixelSize: 17; font.weight: Font.Black; font.letterSpacing: -0.5 }
    }

    Row {
        anchors { right: parent.right; rightMargin: 16; verticalCenter: parent.verticalCenter }
        spacing: 10

        // LIVE status badge
        Rectangle {
            height: 24; radius: 12
            color: "rgba(0,229,160,0.08)"
            border.color: "rgba(0,229,160,0.2)"; border.width: 1
            implicitWidth: statusRow.implicitWidth + 20

            Row {
                id: statusRow
                anchors.centerIn: parent
                spacing: 5
                // Yanıb-sönən nöqtə (pulse)
                Rectangle {
                    width: 5; height: 5; radius: 2.5
                    color: "#00e5a0"
                    anchors.verticalCenter: parent.verticalCenter
                    SequentialAnimation on opacity {
                        loops: Animation.Infinite
                        NumberAnimation { to: 0.3; duration: 1000 }
                        NumberAnimation { to: 1.0; duration: 1000 }
                    }
                }
                Text {
                    text: app.statusText
                    color: "#00e5a0"; font.pixelSize: 10; font.family: "Courier New"
                }
            }
        }

        // 🔑 API Key dəyiş düyməsi
        Rectangle {
            width: 34; height: 34; radius: 8
            color: "#1a1d2b"
            border.color: "rgba(255,255,255,0.07)"; border.width: 1
            Text { anchors.centerIn: parent; text: "🔑"; font.pixelSize: 16 }
            MouseArea {
                anchors.fill: parent
                onClicked: {
                    // ApiModal-ı aç
                    var modal = parent.parent.parent.parent.parent
                    // Root-dan apiModal-ı tap
                    apiModal.open()
                }
            }
        }

        // ⏻ Çıxış düyməsi
        Rectangle {
            width: 34; height: 34; radius: 8
            color: "#1a1d2b"
            border.color: "rgba(255,255,255,0.07)"; border.width: 1
            Text { anchors.centerIn: parent; text: "⏻"; font.pixelSize: 16; color: "#5a5f6e" }
            MouseArea {
                anchors.fill: parent
                onClicked: app.doLogout()
            }
        }
    }
}
