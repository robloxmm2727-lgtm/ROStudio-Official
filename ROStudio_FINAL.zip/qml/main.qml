// ═══════════════════════════════════════════════════════════════════════════════
//  ROStudio v5 — qml/main.qml  (Android + iOS yenilənmiş)
// ═══════════════════════════════════════════════════════════════════════════════
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Window 2.15

ApplicationWindow {
    id: root
    visible: true
    width:  390
    height: 844
    title: "ROStudio"
    color: "#080a10"

    readonly property bool isIOS:     Qt.platform.os === "ios"
    readonly property bool isAndroid: Qt.platform.os === "android"
    readonly property bool isMobile:  isIOS || isAndroid

    // iOS Safe Area (notch / Dynamic Island)
    readonly property real safeTop:    isIOS ? 44 : 0
    readonly property real safeBottom: isIOS ? 34 : 0

    QtObject {
        id: theme
        readonly property color bgDeep:    "#080a10"
        readonly property color bgCard:    "#131620"
        readonly property color accent:    "#7c6bff"
        readonly property color accent2:   "#00e5a0"
        readonly property color amber:     "#ffb547"
        readonly property color red:       "#ff5f5f"
        readonly property color text:      "#e8eaf2"
        readonly property color textMuted: "#5a5f6e"
        readonly property string fontMono: "Courier New"
        readonly property int radius:      14
    }

    // iOS status bar boşluğu
    Rectangle {
        visible: isIOS
        anchors { top: parent.top; left: parent.left; right: parent.right }
        height: safeTop
        color: "#080a10"
        z: 100
    }

    StackView {
        id: screenStack
        anchors {
            top: parent.top; topMargin: isIOS ? safeTop : 0
            bottom: parent.bottom; bottomMargin: isIOS ? safeBottom : 0
            left: parent.left; right: parent.right
        }
        initialItem: app.isLoggedIn ? mainScreen : loginScreen
    }

    Component { id: loginScreen; LoginScreen { } }
    Component { id: mainScreen;  MainScreen  { } }

    Connections {
        target: app
        function onLoginSuccess()      { screenStack.replace(null, mainScreen) }
        function onLoginStateChanged() {
            if (!app.isLoggedIn) screenStack.replace(null, loginScreen)
        }
    }

    Toast {
        id: globalToast
        anchors.bottom: parent.bottom
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottomMargin: (isIOS ? safeBottom : 0) + 30
        z: 999
    }

    Connections {
        target: app
        function onToastRequested() {
            globalToast.show(app.toastMsg, app.toastType)
        }
    }

    // Android geri düyməsi
    Shortcut {
        sequence: StandardKey.Back
        enabled: isAndroid
        onActivated: {
            if (app.activePanel !== "dashboard") app.switchPanel("dashboard")
        }
    }
}
